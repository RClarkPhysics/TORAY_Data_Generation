# -*-Python-*-
# Created by grierson at 04 Mar 2022  06:47

tmp = []

# These settings fix the number of rays - we've forced it to 128
a = '''written by OMFIT
 &EDATA
  smax =       250.000
  ds =      0.500000
  dsmin =      0.200000
  pwrfmin =    0.00100000
  igafit =        1
  fdout =       2.00000
  nharm =        2
  mray(1) =        1
  mray(2) =        5
  mray(3) =       12
  mray(4) =       12
  gauszone =        7
  netcdfdat = .true.
  cqldat = .false.
  nlout(1) = .false.
  nlout(2) = .false.
 &END_OF_EDATA

 '''

tmp.append(a)

printi('Initial `torayin` file generated.')
root['INPUTS']['toray.in'] = OMFITnamelist('toray.in', fromString='\n'.join(tmp))
