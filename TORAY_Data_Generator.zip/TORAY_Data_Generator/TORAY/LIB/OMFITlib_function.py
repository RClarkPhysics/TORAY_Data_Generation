# -*-Python-*-
# Created by mcclenaghanj at 06 Aug 2019  08:12

beam = 'beam'


def get_gyros(ec_launchers=None):
    if ec_launchers is None:
        ec_launchers = root['INPUTS']['ods']['ec_launchers']
    gyros = [item for index, item in enumerate(ec_launchers[beam]) if ec_launchers['code.parameters'][beam][index]['ON']]

    gyroNames = []
    for i in gyros:
        gyroNames.append(ec_launchers[beam][i]['identifier'])
    return gyros, gyroNames


def get_time_indices(igyro, time=None, ec_launchers=None):
    if ec_launchers is None:
        ec_launchers = root['INPUTS']['ods']['ec_launchers']

    if time is None:
        if root['SETTINGS']['EXPERIMENT']['gyro_time'] is not None:
            time = copy.deepcopy(root['SETTINGS']['EXPERIMENT']['gyro_time'])
        else:
            time = float(copy.deepcopy(root['SETTINGS']['EXPERIMENT']['time']))

    time *= 1e-3
    ods = root['INPUTS']['ods']
    itime = np.argmin((time - ec_launchers[f'beam[{igyro}].time']) ** 2)
    itime_freq = np.argmin((time - ec_launchers[f'beam[{igyro}].frequency.time']) ** 2)
    itime_power = np.argmin((time - ec_launchers[f'beam[{igyro}].power_launched.time']) ** 2)
    return itime, itime_freq, itime_power


def get_OMFITprofiles_data(location, time):
    if 'DERIVED' not in location['OUTPUTS']:
        printe("OMFITprofiles must have DERIVED quantities calculated")
        return
    derq = location['OUTPUTS']['DERIVED']
    root['DATA']['rho'] = nominal_values((derq['rho'] + derq['n_e'] * 0).sel(time=time, method='nearest').values)
    root['DATA']['ne'] = nominal_values(derq['n_e'].sel(time=time, method='nearest').values) / 1e19
    root['DATA']['Te'] = nominal_values(derq['T_e'].sel(time=time, method='nearest').values) / 1e3
    if 'gEQDSK' not in location['OUTPUTS']:
        location['SCRIPTS']['EXPORT']['generateGfiles'].run()
    root['INPUTS']['gEQDSK'] = location['OUTPUTS']['gEQDSK'][time]


def get_QUICKFIT_data(location, time):
    if 'FIT' not in location['OUTPUTS']:
        printe("QUICKFIT must have FIT in OUTPUTS")
        return
    fit = location['OUTPUTS']['FIT']
    root['DATA']['rho'] = nominal_values((fit['rho'] + fit['n_e'] * 0).sel(time=time, method='nearest').values)
    root['DATA']['ne'] = nominal_values(fit['n_e'].sel(time=time, method='nearest').values) / 1e19
    root['DATA']['Te'] = nominal_values(fit['T_e'].sel(time=time, method='nearest').values) / 1e3

    efit = location['SETTINGS']['PHYSICS']['EFIT']
    shot = location['SETTINGS']['EXPERIMENT']['shot']
    device = location['SETTINGS']['EXPERIMENT']['device']
    time = int(root['SETTINGS']['EXPERIMENT']['time'])
    root['INPUTS']['gEQDSK'] = OMFITgeqdsk('g%06d.%05d' % (shot, time)).from_mdsplus(device='DIII-D', shot=shot, time=time, SNAPfile=efit)


def get_kineticEFITtime_data(location, time):
    if 'DERIVED' not in location['OMFITprofiles']['OUTPUTS']:
        printe("OMFITprofiles must have DERIVED quantities calculated")
        return
    derq = location['OMFITprofiles']['OUTPUTS']['DERIVED']
    root['DATA']['rho'] = nominal_values((derq['rho'] + derq['n_e'] * 0).sel(time=time, method='nearest').values)
    root['DATA']['ne'] = nominal_values(derq['n_e'].sel(time=time, method='nearest').values) / 1e19
    root['DATA']['Te'] = nominal_values(derq['T_e'].sel(time=time, method='nearest').values) / 1e3
    root['INPUTS']['gEQDSK'] = location['EFITtime']['OUTPUTS']['gEQDSK'][time]
