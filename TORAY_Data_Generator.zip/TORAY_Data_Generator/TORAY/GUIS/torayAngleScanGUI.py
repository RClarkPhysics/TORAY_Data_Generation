# -*-Python-*-
# Created by mcclenaghanj at 07 Nov 2017  23:15
from OMFITlib_functions import get_gyros

OMFITx.TitleGUI('TORAY ANGLE SCAN GUI')


# ============================
OMFITx.Tab('Run')

OMFITx.Separator('Scan parameters')

gyros, gyroNames = get_gyros()

OMFITx.ComboBox("scratch['gyrotron']", gyroNames, lbl='gyrotron', default=None)

OMFITx.Entry(
    "root['SETTINGS']['PHYSICS']['pol_range']",
    'pol grid',
    help='array of poloidal angles (e.g. [90,95,100,105,110,115,120], or np.arange(90,125,5))',
)
OMFITx.Entry(
    "root['SETTINGS']['PHYSICS']['tor_range']",
    'tor grid',
    help='array of poloidal angles (e.g. [180,185,190,195,200,205,210,215], or np.arange(180,220,5))',
)
OMFITx.ComboBox(
    "root['SETTINGS']['PHYSICS']['CPUs']",
    [1, 2, 4, 6, 12],
    'CPUs',
    help='number of processors to use',
)

OMFITx.Button('Run Angle scan', root['SCRIPTS']['scan_angles'])

runid = root['SETTINGS']['EXPERIMENT']['runid']
if any([len(root.get('ANGLE_SCAN_FILES_' + g + '_' + runid, [])) > 0 for g in gyroNames]):
    OMFITx.Separator('Plotting')
    OMFITx.Button('Plot fraction absorbed', lambda: root['PLOTS']['plotAngleScan'].plotFigure(zaxis='frac_absorbed'))
    OMFITx.Button('Plot peak rho', lambda: root['PLOTS']['plotAngleScan'].plotFigure(zaxis='rho_max'))
    OMFITx.Button('Plot driven current', lambda: root['PLOTS']['plotAngleScan'].plotFigure(zaxis='currf'))
    OMFITx.Button('Plot summary', lambda: root['PLOTS']['plotAngleScanProfile'].plotFigure())

# ============================
OMFITx.Tab('Edit gyrotron')

OMFITx.CompoundGUI(root['GUIS']['editGyrotronData'], '')
