# -*-Python-*-
# Created by mcclenaghanj at 03 Nov 2017  14:39

OMFITx.TitleGUI('TORAY SCAN GUI')

# ============================
OMFITx.Tab('Run')

OMFITx.Separator('Active Gyrotrons')

OMFITx.CompoundGUI(root['GUIS']['gyrotron_checkbox'], '')

OMFITx.Separator('Scan parameters')
OMFITx.Entry(
    "root['SETTINGS']['PHYSICS']['time_range']", 'Time range', help='Solves for critical density in time range from time1 to time2'
)
OMFITx.Entry(
    "root['SETTINGS']['PHYSICS']['time_skip']",
    'Time skip',
    help='''
              Skipped number of times in mdsplus data. For EFIT01s: 1~every 20ms, 5~100ms, etc
              ''',
)
OMFITx.CheckBox(
    "root['SETTINGS']['SETUP']['updateGyrotrons']", 'Use gyrotron time data', help='Update gyrotron data at each time', updateGUI=True
)
OMFITx.Entry(
    "root['SETTINGS']['PHYSICS']['uncertainty']",
    'Uncertainty',
    help='''
              Uncertainty in the calculation the TORAY predicted critical density
              ''',
)
OMFITx.Button('Find critical density', root['SCRIPTS']['toray_time_scan'])

if len(root['SCAN_FILES']) > 0:
    OMFITx.Separator('Plotting')
    OMFITx.Button('Plot critical density', root['PLOTS']['plotCriticalScan'].plotFigure)

# ============================
OMFITx.Tab('Edit gyrotron')

OMFITx.CompoundGUI(root['GUIS']['editGyrotronData'], '')
