# -*-Python-*-
# Created by mcclenaghanj at 07 Aug 2019  10:14

OMFITx.TitleGUI('TORAY SCAN GUI')

# ============================
OMFITx.Tab('Run')

OMFITx.Separator('Active Gyrotrons')
OMFITx.CompoundGUI(root['GUIS']['gyrotron_checkbox'], '')
OMFITx.Separator('Scan parameters')
OMFITx.Entry("root['SETTINGS']['EXPERIMENT']['times']", 'Times [ms]', check=is_array, default=[root['SETTINGS']['EXPERIMENT']['time']])

OMFITx.CheckBox(
    "root['SETTINGS']['SETUP']['update_profiles']",
    'Use profile & equilibrium time data',
    help='Update profiles and equilibrium at each time. \nOtherwise, use current INPUTS and DATA.',
    default=True,
    updateGUI=False,
)
OMFITx.CheckBox(
    "root['SETTINGS']['SETUP']['updateGyrotrons']", 'Use gyrotron time data', help='Update gyrotron data at each time', updateGUI=True
)

OMFITx.Button('Run TORAY time scan', root['SCRIPTS']['toray_time_scan'])

if len(root['SCAN_FILES']) > 0:
    OMFITx.Separator('Plotting')
    OMFITx.Button('Plot average current drive', root['PLOTS']['plotTimeAvgCurrent'].run)

# ============================

if not root['SETTINGS']['SETUP']['updateGyrotrons']:
    OMFITx.Tab('Edit gyrotron')
    OMFITx.CompoundGUI(root['GUIS']['editGyrotronData'], '')
