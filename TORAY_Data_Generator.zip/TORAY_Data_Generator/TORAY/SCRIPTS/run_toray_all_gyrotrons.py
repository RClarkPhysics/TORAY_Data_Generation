# -*-Python-*-
# Created by mcclenaghanj at 04 Nov 2017  01:30

from OMFITlib_functions import get_gyros, get_time_indices

defaultVars(ne_scale=1.0, te_scale=1.0, ec_launchers=root['INPUTS']['ods']['ec_launchers'])

gyros, gyroNames = get_gyros(ec_launchers)

root['SCRIPTS']['generate_psiin'].runNoGUI(make_eqdsk=False)

if not root['SETTINGS']['PHYSICS']['append_scan_results']:
    root['OUTPUTS'] = OMFITtree('')

root.setdefault('OUTPUTS', OMFITtree())


echins = root['SCRIPTS']['generate_echin'].prun(
    len(gyros),
    len(gyros),
    'results',
    gyrotron=gyros,
    ne_scale=ne_scale,
    te_scale=te_scale,
    runIDs=gyroNames,
    postrun='''results=root['INPUTS']['echin']''',
    ec_launchers=ec_launchers,
)
for name in echins:
    root['INPUTS'][f'echin_{name}'] = echins[name]

inbeams = root['SCRIPTS']['generate_inbeam'].prun(
    len(gyros),
    len(gyros),
    'results',
    gyrotron=gyros,
    runIDs=gyroNames,
    postrun='''results=root['INPUTS']['inbeam']''',
    ec_launchers=ec_launchers,
)
for name in inbeams:
    root['INPUTS'][f'inbeam_{name}'] = inbeams[name]
server = root['SETTINGS']['REMOTE_SETUP']['serverPicker']
qos = None
vmem_per_node = None
walltime_min = 5
constraint = None
inputs = [
    root['INPUTS']['psiin'],
    root['INPUTS']['toray.in'].filename,
    root['INPUTS']['topfile'],
    root['INPUTS']['ne'],
    root['INPUTS']['Te'],
]
if server in OMFITclusters:
    batch_lines = []
    for name in gyroNames:
        inputs.append(root['INPUTS'][f'echin_{name}'])
        batch_lines.append(
            f'rm -rf {name}; mkdir {name}; cd {name}; '
            'ln -s ../psiin ../toray.in ./;'
            'ln -s ../echin_{name} echin;'
            '{toray_exe}; '
            'mv toray.nc ../toray_{name}.nc;'.format(name=name, toray_exe=root['SETTINGS']['SETUP']['executable'])
        )
    outputs = ['toray*.nc']
    torbeam_outputs = []
    if root['SETTINGS']['SETUP']['executable_TORBEAM'] != "undefined":
        torbeam_outputs = ['t1_LIB*.dat', 't1tor_LIB*.dat', 't2_new_LIB*.dat', "rhoresult*.dat"]
        outputs += torbeam_outputs
        for name in gyroNames:
            inputs.append(root['INPUTS'][f'inbeam_{name}'])
            batch_lines.append(
                f'rm -rf {name}_TORBEAM; mkdir {name}_TORBEAM; cd {name}_TORBEAM; '
                'ln -s ../topfile ../Te.dat ../ne.dat ./;'
                'ln -s ../inbeam_{name}.dat inbeam.dat;'
                '{torbeam_exe}; '
                'mv t1_LIB.dat ../t1_LIB_{name}.dat;'
                'mv t1tor_LIB.dat ../t1tor_LIB_{name}.dat;'
                'mv t2_new_LIB.dat ../t2_new_LIB_{name}.dat;'
                'mv rhoresult.dat ../rhoresult_{name}.dat;'.format(name=name, torbeam_exe=root['SETTINGS']['SETUP']['executable_TORBEAM'])
            )
        ran_torbeam = True
    batch_info = OMFITclusters.get_batch_simple(
        cluster=server,
        wall_time=walltime_min / 60.0,
        ntasks=1,
        cpus_per_task=1,
        qos=qos,
        vmem_per_node=vmem_per_node,
        constraint=constraint,
    )
    batch_info['job_time'] = '0:02:00'
    OMFITx.job_array(root, batch_lines=batch_lines, environment="", inputs=inputs, outputs=outputs, **batch_info)
    logs = scratch.setdefault('logs', OMFITtree())
    for name in gyroNames:
        root['OUTPUTS'][name] = OMFITtree()
        i_gy = list(ec_launchers['beam[:].identifier']).index(name)
        itime, itime_freq, itime_power = get_time_indices(i_gy, ec_launchers=ec_launchers)
        power = ec_launchers['beam'][i_gy]['power_launched']['data'][itime_power]
        try:
            root['OUTPUTS'][name]["toray.nc"] = OMFITnc(f"toray_{name}.nc")
        except Exception as e:
            print(f"Failed to get Toray result for gyrotron {name}")
            print(f"Cause {e}")
        if len(torbeam_outputs) > 0:
            root['OUTPUTS'][name]["torbeam"] = OMFITcollection()
            try:
                Rz_rays = np.loadtxt(f"t1_LIB_{name}.dat")
                xy_rays = np.loadtxt(f"t1tor_LIB_{name}.dat")
                depo = np.loadtxt(f"t2_new_LIB_{name}.dat")
                rhoresult = np.loadtxt(f"rhoresult_{name}.dat")
                columns = np.array([0, 2, 4])
                for key, offset, source in zip(["R", "z", "x", "y"], [0, 1, 0, 1], [Rz_rays, Rz_rays, xy_rays, xy_rays]):
                    root['OUTPUTS'][name]["torbeam"][key] = source.T[columns + offset] * 1.0e-2  # cm -> m
                x_ray = root['OUTPUTS'][name]["torbeam"]["x"]
                y_ray = root['OUTPUTS'][name]["torbeam"]["y"]
                phi_launch = ec_launchers[f'beam[{i_gy}].launching_position.phi']
                root['OUTPUTS'][name]["torbeam"]["x"] = x_ray * np.cos(phi_launch) - y_ray * np.sin(phi_launch)
                root['OUTPUTS'][name]["torbeam"]["y"] = x_ray * np.sin(phi_launch) + y_ray * np.cos(phi_launch)
                root['OUTPUTS'][name]["torbeam"]["phi"] = np.arctan2(
                    root['OUTPUTS'][name]["torbeam"]["y"], root['OUTPUTS'][name]["torbeam"]["x"]
                )
                root['OUTPUTS'][name]["torbeam"]["rho"] = depo.T[0]
                root['OUTPUTS'][name]["torbeam"]["power density"] = depo.T[1]
                root['OUTPUTS'][name]["torbeam"]["current density"] = depo.T[2]

                root['OUTPUTS'][name]["torbeam"]["absorbed_power_fraction"] = rhoresult[13] * 1.0e6  # We launched 1 W
                root['OUTPUTS'][name]["torbeam"]["total_current_drive"] = rhoresult[12] * power * 1.0e3  # kA -> A
                root['OUTPUTS'][name]["torbeam"]["current_drive_efficiency"] = rhoresult[12] * 1.0e3
                root['OUTPUTS'][name]["torbeam"]["peak_absorption_rho"] = rhoresult[0]
                root['OUTPUTS'][name]["torbeam"]["peak_absorption_R"] = rhoresult[1] / 1.0e2  # cm -> m
                root['OUTPUTS'][name]["torbeam"]["peak_absorption_z"] = rhoresult[2] / 1.0e2  # cm -> m
            except Exception as e:
                print(f"Failed to get TORBEAM result for gyrotron {name}")
                print(f"Cause {e}")
                del root['OUTPUTS'][name]["torbeam"]
