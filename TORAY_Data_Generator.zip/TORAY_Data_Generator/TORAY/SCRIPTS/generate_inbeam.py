# -*-Python-*-
# Created by meneghini at 2013/04/23 18:50

# The rf beam at the center of the tokamak is 10 cm in diameter at the -20 dB contour,
# with an oval shape depending on the angle, and on the flat turning mirror it's more like 3 cm at -20 dB.
# I would adjust them until the dispersion half-power half-angle is 1.7 deg in the far field region.
# I figured once that the cone apex is a few cm behind the steering mirror (r_antenna, z_antenna).
from OMFITlib_functions import get_time_indices

defaultVars(gyrotron='???', gEQDSK=root['INPUTS']['gEQDSK'], ec_launchers=root['INPUTS']['ods']['ec_launchers'])
itime, itime_freq, itime_power = get_time_indices(gyrotron, ec_launchers=ec_launchers)
beam = ec_launchers['beam'][gyrotron]
root['INPUTS']['inbeam'] = root['TEMPLATES'][f'inbeam'].duplicate(f'inbeam_{beam["identifier"]}.dat')
# Converting from toroidal/poloidal steering angles to Euler angles
# To be like TORAY power needs to be set to one 1 W, TORBEAM expects MW
root['INPUTS']['inbeam']['edata']['xpw0'] = 1.0e-6
if np.abs(beam['mode']) != 1:
    printw(f"Warning incorrect mode in ods {beam['mode']} assuming X-mode")
    root['INPUTS']['inbeam']['edata']['nmod'] = -1
else:
    root['INPUTS']['inbeam']['edata']['nmod'] = beam['mode']

root['INPUTS']['inbeam']['edata']['xf'] = beam['frequency.data'][itime_freq]
if np.any(np.abs(beam['phase.curvature']) < 2.0e-4):
    root['INPUTS']['inbeam']['edata']['xryyb'] = 50.0e2  # 50 [m] in case of non-focused beam
    root['INPUTS']['inbeam']['edata']['xrzzb'] = 50.0e2  # 50 [m] in case of non-focused beam
else:
    root['INPUTS']['inbeam']['edata']['xryyb'] = 1.0 / float(beam['phase.curvature'][0])
    root['INPUTS']['inbeam']['edata']['xrzzb'] = 1.0 / float(beam['phase.curvature'][1])
root['INPUTS']['inbeam']['edata']['xwyyb'] = float(beam['spot.size'][0]) * 1.0e2  # TORBEAM wants cm
root['INPUTS']['inbeam']['edata']['xwzzb'] = float(beam['spot.size'][1]) * 1.0e2  # TORBEAM wants cm


r = beam['launching_position.r'][itime] * 1.0e2
phi = 0.0  # Torbeam acts a bit funky for non-zero toroidal position. This is fixed in post-processing
root['INPUTS']['inbeam']['edata']['xxb'] = r * np.cos(phi)
root['INPUTS']['inbeam']['edata']['xyb'] = r * np.sin(phi)
root['INPUTS']['inbeam']['edata']['xzb'] = beam['launching_position.z'][itime] * 1.0e2

root['INPUTS']['inbeam']['edata']['xtordeg'] = -np.rad2deg(beam['steering_angle_tor'][itime])
root['INPUTS']['inbeam']['edata']['xpoldeg'] = np.rad2deg(beam['steering_angle_pol'][itime])

root['INPUTS']['inbeam']['edata']['xrmaj'] = gEQDSK['RMAXIS'] * 100
root['INPUTS']['inbeam']['edata']['xrmin'] = (max(gEQDSK['RBBBS']) - min(gEQDSK['RBBBS'])) / 2.0 * 100
root['INPUTS']['inbeam']['edata']['xb0'] = abs(gEQDSK['BCENTR'])
