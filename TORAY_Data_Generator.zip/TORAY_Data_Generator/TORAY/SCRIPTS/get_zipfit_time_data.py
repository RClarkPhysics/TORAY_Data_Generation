# -*-Python-*-
# Created by mcclenaghanj at 05 Aug 2019  17:08

defaultVars(
    times=root['SETTINGS']['EXPERIMENT']['times'],
    shot=root['SETTINGS']['EXPERIMENT']['shot'],
)

# make sure times is an array
times = atleast_1d(times)

# Get ne ZIPFITs
tmp = OMFITmdsValue(
    server=root['SETTINGS']['EXPERIMENT']['device'], treename='ELECTRONS', shot=shot, TDI='\\ELECTRONS::TOP.PROFILE_FITS.ZIPFIT.EDENSFIT'
)
rho_ne = tmp.dim_of(0)
time_ne = np.atleast_1d(tmp.dim_of(1))
ne_zip = tmp._base_data()[:]
ne_interp = scipy.interpolate.interp2d(rho_ne, time_ne, ne_zip, bounds_error=False)
if time_ne.min() > times.min() or time_ne.max() < times.max():
    printw("Some of the times are beyond the bounds of available ne ZIPFITs. Profiles will be extended using nearest time.")

# Get Te ZIPFITS
tmp = OMFITmdsValue(
    server=root['SETTINGS']['EXPERIMENT']['device'], treename='ELECTRONS', shot=shot, TDI='\\ELECTRONS::TOP.PROFILE_FITS.ZIPFIT.ETEMPFIT'
)
rho_te = tmp.dim_of(0)
time_te = np.atleast_1d(tmp.dim_of(1))
Te_zip = tmp._base_data()[:]
Te_interp = scipy.interpolate.interp2d(rho_te, time_te, Te_zip, bounds_error=False)
if time_te.min() > times.min() or time_te.max() < times.max():
    printw("Some of the times are beyond the bounds of available te ZIPFITs. Profiles will be extended using nearest time.")

# Interpolate Te, ne zipfit gfile times
Te_sim = Te_interp(rho_te, times)
ne_sim = ne_interp(rho_ne, times)

# Save data set in root['DATA_ALL'] to be called for parallel runs
root['DATA_ALL'] = OMFITtree("")
root['DATA_ALL']['ne'] = ne_sim
root['DATA_ALL']['Te'] = Te_sim
root['DATA_ALL']['times'] = times
root['DATA_ALL']['rho'] = rho_ne

if root['SETTINGS']['SETUP']['get_neline']:
    tmp = OMFITmdsValue(server='DIII-D', treename='None', shot=shot, TDI='density')
    t_density = copy.deepcopy(tmp.dim_of(0)[:])
    density = copy.deepcopy(tmp._base_data()[:]) * 1e-13
    tck = scipy.interpolate.splrep(t_density, density, k=3)
    root['DATA_ALL']['neline'] = density_shared = scipy.interpolate.splev(times, tck)

root['DATA_ALL']['gEQDSKs'] = OMFITtree("")
for i in times:
    root['DATA_ALL']['gEQDSKs'][int(i)] = OMFITgeqdsk('g%06d.%05d' % (shot, int(i))).from_mdsplus(
        device='DIII-D',
        shot=shot,
        time=int(i),
        SNAPfile=root['SETTINGS']['PHYSICS']['EFIT_type'],
        fail_if_out_of_range=False,
        time_diff_warning_threshold=20,
    )
