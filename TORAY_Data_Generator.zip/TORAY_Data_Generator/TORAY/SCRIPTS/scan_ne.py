# -*-Python-*-
# Created by mcclenaghanj at 09 Jun 2017  16:34

if not root['SETTINGS']['PHYSICS']['append_scan_results']:
    root['NE_SCAN_FILES'].clear()

for ne_scale in root['SETTINGS']['PHYSICS']['ne_scan']:
    root['OUTPUTS'].clear()
    root['SCRIPTS']['run_toray_all_gyrotrons'].run(ne_scale=ne_scale)
    root['NE_SCAN_FILES'].setdefault(ne_scale, OMFITtree())
    root['NE_SCAN_FILES'][ne_scale].update(root['OUTPUTS'])
root['NE_SCAN_FILES'].sort()
