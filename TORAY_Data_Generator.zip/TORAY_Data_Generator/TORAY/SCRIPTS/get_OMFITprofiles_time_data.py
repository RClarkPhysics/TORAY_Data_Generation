# -*-Python-*-
# Created by mcclenaghanj at 30 Aug 2019  09:03

from OMFITlib_functions import get_OMFITprofiles_data, get_QUICKFIT_data, get_kineticEFITtime_data

defaultVars(times=root['SETTINGS']['EXPERIMENT']['times'])

# make sure times is an array
times = atleast_1d(times)

root['DATA_ALL']['ne'] = []
root['DATA_ALL']['Te'] = []
root['DATA_ALL']['times'] = []
root['DATA_ALL']['gEQDSKs'] = OMFITcollection()

if not root['SETTINGS']['SETUP']['update_profiles']:
    for time in times:
        root['DATA_ALL']['ne'].append(root['DATA']['ne'])
        root['DATA_ALL']['Te'].append(root['DATA']['Te'])
        root['DATA_ALL']['times'].append(time)
        root['DATA_ALL']['gEQDSKs'][time] = root['INPUTS']['gEQDSK'].duplicate()
        root['DATA_ALL']['rho'] = root['DATA']['rho']
else:
    for time in times:
        if root['SETTINGS']['PHYSICS']['inputDATA'] == 'kineticEFITtime':
            get_kineticEFITtime_data(kineticEFITtime, time)
        elif root['SETTINGS']['PHYSICS']['inputDATA'] == 'QUICKFIT':
            get_kineticEFITtime_data(kineticEFITtime, time)
        elif root['SETTINGS']['PHYSICS']['inputDATA'] == 'OMFITprofiles':
            get_OMFITprofiles_data(OMFITprofiles, time)
        else:
            raise OMFITexception("inputDATA source {root['SETTINGS']['PHYSICS']['inputDATA']} is not supported")
        root['DATA_ALL']['ne'].append(root['DATA']['ne'])
        root['DATA_ALL']['Te'].append(root['DATA']['Te'])
        root['DATA_ALL']['times'].append(time)
        root['DATA_ALL']['gEQDSKs'][time] = root['INPUTS']['gEQDSK'].duplicate()
        root['DATA_ALL']['rho'] = root['DATA']['rho']
