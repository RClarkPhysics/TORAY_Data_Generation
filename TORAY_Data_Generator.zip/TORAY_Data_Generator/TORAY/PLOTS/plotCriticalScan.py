# -*-Python-*-
# Created by mcclenaghanj at 12 Jun 2017  15:30

from OMFITlib_functions import get_gyros

gyros, gyroNames = get_gyros()
times = root['SCAN_FILES'].keys()
crit_ne = {}
crit_ne_min = 1000.0

if 'neline' in root['SCAN_FILES'][times[0]][gyroNames[0]]:
    crit_value = 'neline'
    crit_name = 'line-averaged'
else:
    crit_value = 'ne'
    crit_name = 'central'

for gyro in gyroNames:
    crit_ne[gyro] = []
    for time in times:
        try:
            crit_ne[gyro].append(root['SCAN_FILES'][time][gyro][crit_value])
            if crit_ne_min > root['SCAN_FILES'][time][gyro][crit_value]:
                crit_ne_min = copy.deepcopy(root['SCAN_FILES'][time][gyro][crit_value])
        except Exception as _excp:
            printe(repr(_excp))

    plot(times, crit_ne[gyro], '.-', label=gyro)

if len(times):
    time_min = times[0]
    crit_ne_min = float(floor(1000 * crit_ne_min)) / 1000.0
    xlabel('time(ms)', fontsize=14)
    ylabel(r'critical %s density $10^{19}$ $m^{-3}$' % crit_name, fontsize=14)
    ylim([0, 13.0])
    text(time_min, 1.0, r'critical %s $n_{e}$ = %s   $10^{19}$ $m^{-3}$' % (crit_name, str(crit_ne_min)), fontsize=14)

    legend()

    tight_layout()

row_format = "{:>11}" * (len(gyros) + 1)
print('-------- Critical %s density --------' % (crit_name))
print(row_format.format("time", *gyros))
for itime, time in enumerate(times):  # column, row in zip(time, np.array(crit_ne).T):
    row = []
    for gyro in gyroNames:
        print(crit_ne)
        row.append(round(crit_ne[gyro][itime], 3))
    print(row_format.format(time, *row))
