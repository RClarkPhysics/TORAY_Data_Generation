A = [1,2,3]

for a in A:
    print(a)