# -*-Python-*-
# Created by mcclenaghanj at 07 Nov 2017  23:08

# This code will build the neccesary entries of EQDSK for TORAY-GA out of the EQ of omfitprofiles
# The option to copy the ODS should be used if multiple TORAY modules are used in a single project

defaultVars(copy_ods=False)

from OMFITlib_functions import get_OMFITprofiles_data, get_QUICKFIT_data, get_kineticEFITtime_data

if root['SETTINGS']['PHYSICS']['inputDATA'] == 'OMFITprofiles':
    get_OMFITprofiles_data(profiles_module, root['SETTINGS']['EXPERIMENT']['time'])

elif root['SETTINGS']['PHYSICS']['inputDATA'] == 'QUICKFIT':
    get_QUICKFIT_data(profiles_module, root['SETTINGS']['EXPERIMENT']['time'])


elif root['SETTINGS']['PHYSICS']['inputDATA'] == 'kineticEFITtime':
    get_kineticEFITtime_data(kineticEFITtime, root['SETTINGS']['EXPERIMENT']['time'])

elif root['SETTINGS']['PHYSICS']['inputDATA'] == 'ODS' or root['SETTINGS']['PHYSICS']['inputDATA'] == 'PRO_create':
    if root['SETTINGS']['PHYSICS']['inputDATA'] == 'PRO_create':
        if copy_ods:
            root['INPUTS']['ods'] = copy.deepcopy(PRO_create['OUTPUTS']['ods'])
        else:
            root['INPUTS']['ods'] = PRO_create['OUTPUTS']['ods']
    ods = root['INPUTS']['ods']
    root['DATA']['rho'] = ods['core_profiles']['profiles_1d'][0]['grid']['rho_tor_norm']
    root['DATA']['ne'] = ods['core_profiles']['profiles_1d'][0]['electrons']['density'] * 1e-19
    root['DATA']['Te'] = ods['core_profiles']['profiles_1d'][0]['electrons']['temperature'] * 1e-3
    root['INPUTS']['gEQDSK'] = OMFITgeqdsk('gfile').from_omas(ods, time_index=0)
else:
    shot = root['SETTINGS']['EXPERIMENT']['shot']
    time = int(root['SETTINGS']['EXPERIMENT']['time'])
    tmp = OMFITmdsValue(
        server=root['SETTINGS']['EXPERIMENT']['device'],
        treename='ELECTRONS',
        shot=shot,
        TDI='\\ELECTRONS::TOP.PROFILE_FITS.ZIPFIT.EDENSFIT',
    )

    rho = tmp.dim_of(0)
    time_ne = list(tmp.dim_of(1))
    ne_zip = tmp._base_data()[:]
    # Get Te ZIPFITS
    tmp = OMFITmdsValue(
        server=root['SETTINGS']['EXPERIMENT']['device'],
        treename='ELECTRONS',
        shot=shot,
        TDI='\\ELECTRONS::TOP.PROFILE_FITS.ZIPFIT.ETEMPFIT',
    )

    rho_te = tmp.dim_of(0)
    time_te = list(tmp.dim_of(1))
    Te_zip = tmp._base_data()[:]
    # Get ne and Te index which cooresponds to t=scan_time
    i_ne = time_ne.index(int(root['SETTINGS']['EXPERIMENT']['time']))
    i_te = time_te.index(int(root['SETTINGS']['EXPERIMENT']['time']))

    root['DATA']['rho'] = rho
    root['DATA']['ne'] = ne_zip[i_ne]
    root['DATA']['Te'] = Te_zip[i_te]

    root['INPUTS']['gEQDSK'] = OMFITgeqdsk('g%06d.%05d' % (shot, time)).from_mdsplus(
        device='DIII-D', shot=shot, time=time, SNAPfile=root['SETTINGS']['PHYSICS']['EFIT_type']
    )
root['SCRIPTS']['generate_topfile'].run()
