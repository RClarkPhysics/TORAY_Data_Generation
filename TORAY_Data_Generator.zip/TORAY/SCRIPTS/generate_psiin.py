# -*-Python-*-
# Created by meneghini at 07 Dec 2016  12:45
#

defaultVars(gafsep=1e-5, npts=201, make_eqdsk=True)

write_f = fortranformat.FortranRecordWriter('5E16.9')


def write_array(array, interp=False):
    if interp:
        array = interp1e(psi, array)(psireq)
    for k, item in enumerate(array):
        if k % 5 == 0:
            tmp.append('')
        if not (np.isnan(item)):
            tmp[-1] += write_f.write([item])
        if np.isnan(item):
            tmp[-1] += write_f.write(0.0)


tmp = []
eqdsk = root['INPUTS']['gEQDSK']
if eqdsk['NW'] > 99 and eqdsk['NH'] > 99:
    tmp.append('   2 %d %d %d' % (npts, eqdsk['NW'], eqdsk['NH']))
if eqdsk['NW'] < 99 or eqdsk['NH'] < 99:
    tmp.append('   2 %d  %d  %d' % (npts, eqdsk['NW'], eqdsk['NH']))
write_array([eqdsk['RDIM'], eqdsk['ZDIM'], eqdsk['RCENTR'], eqdsk['RLEFT']])

write_array([eqdsk['RMAXIS'], eqdsk['ZMAXIS'], eqdsk['SIMAG'], eqdsk['SIBRY'], eqdsk['BCENTR'], gafsep])

psin = linspace(0, 1, len(eqdsk['FPOL']))
psi = psin * (eqdsk['SIBRY'] - eqdsk['SIMAG']) + eqdsk['SIMAG']

psir = interp1d(eqdsk['RHOVN'], psi)(linspace(0, 1, npts)) * 1e5
psireq = interp1d(eqdsk['RHOVN'], psi)(linspace(0, 1, len(eqdsk['FPOL'])))
write_array(eqdsk['FPOL'])
write_array(eqdsk['PSIRZ'].flatten())

write_array(psir)
write_array(abs(eqdsk['QPSI']))

bmaxis = eqdsk['fluxSurfaces']['avg']['Btot'][0]

# try:
hf = np.zeros(eqdsk['NW'])
for i in eqdsk['fluxSurfaces']['flux']:
    inputR = eqdsk['fluxSurfaces']['flux'][i]['R']
    inputZ = root['INPUTS']['gEQDSK']['fluxSurfaces']['flux'][i]['Z']
    dl = sqrt(ediff1d(inputR, to_begin=0) ** 2 + ediff1d(inputZ, to_begin=0) ** 2)
    points = len(inputR)
    Bt = np.zeros(points)
    bmax = eqdsk['fluxSurfaces']['flux'][i]['Bmax']
    Bt = eqdsk['fluxSurfaces']['flux'][i]['F'] / inputR
    hf[i] = np.trapz(np.sqrt(1.0 - (Bt / bmax)) * dl)
hf = hf / eqdsk['fluxSurfaces']['geo']['per']
# xcept Exception:
#    hf = eqdsk['fluxSurfaces']['avg']['hf']


tmp.append('  %d   %d' % (eqdsk['NBBBS'], eqdsk['LIMITR']))
write_array(vstack((eqdsk['RBBBS'], eqdsk['ZBBBS'])).T.flatten())
write_array(vstack((eqdsk['RLIM'], eqdsk['ZLIM'])).T.flatten())
write_array(hf, True)
write_array(eqdsk['fluxSurfaces']['avg']['Btot**2'] / bmaxis**2, True)
write_array(abs(eqdsk['fluxSurfaces']['avg']['Btot'] / bmaxis), True)

write_array(eqdsk['fluxSurfaces']['avg']['R'] / eqdsk['RMAXIS'], True)

tmp.append('')

print('New `psiin` file generated based on geqdsk file')
root['INPUTS']['psiin'] = OMFITascii('psiin', fromString='\n'.join(tmp))
