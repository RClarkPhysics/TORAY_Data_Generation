# -*-Python-*-
# Created by meneghini at 2013/02/15 12:02

defaultVars(time=None, single_time=True)


from OMFITlib_functions import get_time_indices


def detimify_ods(ods):
    beams = root['INPUTS']['ods']['ec_launchers.beam']
    for ibeam in beams:
        itime, itime_freq, itime_power = get_time_indices(ibeam, time=time)
        beams[ibeam]['frequency.data'] = np.atleast_1d(beams[ibeam]['frequency.data'][itime_freq])
        beams[ibeam]['frequency.time'] = np.atleast_1d(beams[ibeam]['frequency.time'][itime_freq])

        beams[ibeam]['launching_position.phi'] = np.atleast_1d(beams[ibeam]['launching_position.phi'][itime])
        beams[ibeam]['launching_position.r'] = np.atleast_1d(beams[ibeam]['launching_position.r'][itime])
        beams[ibeam]['launching_position.z'] = np.atleast_1d(beams[ibeam]['launching_position.z'][itime])

        beams[ibeam]['phase.angle'] = np.atleast_1d(beams[ibeam]['phase.angle'][itime])
        beams[ibeam]['phase.curvature'] = np.atleast_2d(beams[ibeam]['phase.curvature'][:, itime]).T

        beams[ibeam]['power_launched.data'] = np.atleast_1d(beams[ibeam]['power_launched.data'][itime_power])
        beams[ibeam]['power_launched.time'] = np.atleast_1d(beams[ibeam]['power_launched.time'][itime_power])

        beams[ibeam]['spot.angle'] = np.atleast_1d(beams[ibeam]['spot.angle'][itime])
        beams[ibeam]['spot.size'] = np.atleast_2d(beams[ibeam]['spot.size'][:, itime]).T

        beams[ibeam]['steering_angle_pol'] = np.atleast_1d(beams[ibeam]['steering_angle_pol'][itime])
        beams[ibeam]['steering_angle_tor'] = np.atleast_1d(beams[ibeam]['steering_angle_tor'][itime])
        beams[ibeam]['time'] = np.atleast_1d(beams[ibeam]['time'][itime])


device = root['SETTINGS']['EXPERIMENT']['device']
if is_device(device, 'DIII-D'):
    from omas.machine_mappings.d3d import ec_launcher_active_hardware
else:
    printe('EC data fetching not supported for this device')
    OMFITx.End()
if root['SETTINGS']['EXPERIMENT']['gyro_shot'] is not None:
    pulse = root['SETTINGS']['EXPERIMENT']['gyro_shot']
else:
    pulse = root['SETTINGS']['EXPERIMENT']['shot']
if 'ods' not in root['INPUTS']:
    root['INPUTS']['ods'] = ODS()
ods = root['INPUTS']['ods']

ec_launcher_active_hardware(ods, pulse)

ods['ec_launchers.code.parameters'] = CodeParameters()
cparam_launchers = ods['ec_launchers.code.parameters']['beam'] = ODS()

for ibeam in ods['ec_launchers.beam']:

    ods['ec_launchers.code.parameters.beam'][ibeam] = ODS()
    ods['ec_launchers.code.parameters.beam'][ibeam]['mharm'] = 2
    ods['ec_launchers.code.parameters.beam'][ibeam]['ON'] = 1

if single_time:
    detimify_ods(ods)
