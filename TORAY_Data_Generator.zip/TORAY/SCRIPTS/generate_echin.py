# -*-Python-*-
# Created by brookmanw at 07 Dec 2016  12:45
#
# this script generates a ECHIN file that contains the profiles data
#
# gnum --> gyrotron number
# slnum --> slice number

defaultVars(
    fitq=None,
    derq=root['DATA'],
    eqdsk=root['INPUTS']['gEQDSK'],
    gafsep=1e-5,
    npts=201,
    nrays=100,
    ne_scale=1.0,
    te_scale=1.0,
    gyrotron=0,
    ec_launchers=root['INPUTS']['ods']['ec_launchers'],
)

from OMFITlib_functions import get_time_indices

write_f = fortranformat.FortranRecordWriter('5E16.9')


def write_array(array, interp=False):
    if interp:
        array = interp1e(psi, array)(psireq)
    for k, item in enumerate(array):
        if k % 5 == 0:
            tmp.append('')
        if not (np.isnan(item)):
            tmp[-1] += write_f.write([item])
        if np.isnan(item):
            tmp[-1] += write_f.write(0.0)


beam = ec_launchers['beam'][gyrotron]
itime, itime_freq, itime_power = get_time_indices(gyrotron, ec_launchers=ec_launchers)
xoxo = 1.0 + 0.5 * (beam['mode'] - 1.0)
tslice = root['SETTINGS']['EXPERIMENT']['time']
phaiech = np.degrees(beam['steering_angle_tor'][itime]) + 180.0
thetech = np.degrees(beam['steering_angle_pol'][itime]) + 90.0
zlau = beam['launching_position.z'][itime] * 100.0
xlau = beam['launching_position.r'][itime] * 100.0
fgy = beam['frequency.data'][itime_freq]

b0 = eqdsk['BCENTR']
Rgrid = eqdsk['fluxSurfaces']['midplane']['R']
#
Rax = eqdsk['RMAXIS'] * 100
psin = linspace(0, 1, len(eqdsk['FPOL']))
psi = psin * (eqdsk['SIBRY'] - eqdsk['SIMAG']) + eqdsk['SIMAG']  # psin
psir = interp1d(eqdsk['RHOVN'], psi)(linspace(0, 1, npts))  # rho
psireq = interp1d(eqdsk['RHOVN'], psi)(linspace(0, 1, len(eqdsk['FPOL'])))

# That boy aint right
ind = derq['rho'] <= 1.0
rho_prof = derq['rho'][ind]
psi_prof = interp1d(eqdsk['RHOVN'], psin)(rho_prof)

Zgrid = 1.75 * np.ones(len(rho_prof))
negrid = ne_scale * derq['ne'][ind] * 1.0e13
Tegrid = te_scale * derq['Te'][ind]

# Calculating rho in cm at LCS
q = eqdsk['QPSI']
phi = trapz(q, psi)
rhoedge = sqrt(abs(2.0 * phi / b0))
# Assembling output structure
tmp = []
tmp.append(write_f.write([tslice]))  # time of calculation
tmp.append('   8 %d %d   3' % (npts, nrays))
nextrow = [fgy, xoxo, xlau, zlau, thetech, phaiech, 1.7, 1, Rax, b0 * 1e4, rhoedge]

psids = linspace(0, psi_prof[-1], npts)  # downsample to the specified npts

# ONETWO cray331.f file says that rho is correct radial coordinate, but psids gives correct ne and Te in output here.
# Maybe ne and Te should not have been interpolated onto psi?.- Joey M.
write_array(nextrow)
write_array(psids)
write_array(interp1d(psi_prof, Zgrid)(psids))
write_array(interp1d(psi_prof, negrid)(psids))
write_array(interp1d(psi_prof, Tegrid)(psids))
tmp.append('')

print('New `echin` file generated based on OMFIT')
root['INPUTS']['echin'] = OMFITascii(f'echin_{beam["identifier"]}', fromString='\n'.join(tmp))
