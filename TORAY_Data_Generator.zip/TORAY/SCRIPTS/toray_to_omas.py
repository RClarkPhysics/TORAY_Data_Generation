# -*-Python-*-
# Created by mcclenaghanj at 22 May 2020  10:17

defaultVars(ods=None, time_index=0, new_sources=True, scale_ec=1.0)

if ods is None and 'ods' in root['INPUTS']:
    root['OUTPUTS']['ods'] = ods = root['INPUTS']['ods'].copy()
else:
    root['OUTPUTS']['ods'] = ods = ODS()

if new_sources or 'core_sources.source' not in ods:
    ods['core_sources']['source'] = ODS()

toray_cocos = 1
presource = len(ods['core_sources']['source'])

if compare_version(ods.imas_version, "3.37.0") >= 0:
    beam = "beam"
else:
    beam = "launcher"

with omas_environment(ods, cocosio=toray_cocos):
    for i, gyrotron in enumerate(root['OUTPUTS']):
        if isinstance(root['OUTPUTS'][gyrotron], OMFITtree):
            i_ods = i + presource
            power = ods['ec_launchers'][beam][i]['power_launched']['data']
            ods['core_sources']['source'][i_ods]['identifier']['description'] = 'Electron heating source'
            ods['core_sources']['source'][i_ods]['identifier']['name'] = gyrotron
            ods['core_sources']['source'][i_ods]['identifier']['index'] = 3

            source = ods['core_sources']['source'][i_ods]['profiles_1d'][time_index]
            source['grid']['rho_tor_norm'] = root['OUTPUTS'][gyrotron]['toray.nc']['xmrho']['data']

            source['j_parallel'] = root['OUTPUTS'][gyrotron]['toray.nc']['currf']['data'] * 1e4 * power * scale_ec
            source['electrons']['energy'] = root['OUTPUTS'][gyrotron]['toray.nc']['weecrh']['data'] * 1e6 * power * scale_ec
