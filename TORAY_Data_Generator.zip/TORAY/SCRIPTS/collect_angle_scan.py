defaultVars(gyrotron=None, POLS=None, TORS=None, runid=root['SETTINGS']['EXPERIMENT']['runid'])


if gyrotron is None:
    raise ValueError("gyrotron must be specified")

if POLS is None or TORS is None:
    tor_range = root['SETTINGS']['PHYSICS']['tor_range']
    pol_range = root['SETTINGS']['PHYSICS']['pol_range']

    POLS, TORS = meshgrid(pol_range, tor_range)
    POLS = np.radians(array(POLS.flatten()) - 90.0)
    TORS = np.radians(array(TORS.flatten()) - 180.0)
angle_scan_id = 'ANGLE_SCAN_FILES_' + gyrotron + '_' + runid
root[angle_scan_id] = OMFITtree()
summary_entries = ['weecrh', 'xmrho']

for i_angle, (pol, tor) in enumerate(zip(POLS.flatten(), TORS.flatten())):
    gy_id = f"{gyrotron}_angscan_{i_angle}"
    root[angle_scan_id][i_angle] = OMFITtree()
    root[angle_scan_id][i_angle]["tor"] = tor
    root[angle_scan_id][i_angle]["pol"] = pol
    for entry in summary_entries:
        root[angle_scan_id][i_angle][entry] = root['OUTPUTS'][gy_id]['toray.nc'][entry]['data']
    root[angle_scan_id][i_angle]["rho_max"] = np.sum(
        root[angle_scan_id][i_angle]['weecrh'] * root[angle_scan_id][i_angle]['xmrho']
    ) / np.sum(root[angle_scan_id][i_angle]['weecrh'])
    root[angle_scan_id][i_angle]["rho_width"] = np.sqrt(
        np.sum(
            np.abs(root[angle_scan_id][i_angle]['weecrh'])
            * (root[angle_scan_id][i_angle]['xmrho'] - root[angle_scan_id][i_angle]["rho_max"]) ** 2
        )
        / np.sum(np.abs(root[angle_scan_id][i_angle]['weecrh']))
    )
    root[angle_scan_id][i_angle]["frac_absorbed"] = root['OUTPUTS'][gy_id]['toray.nc']["tpowde"]['data'][-1]
    root[angle_scan_id][i_angle]["currf"] = root['OUTPUTS'][gy_id]['toray.nc']["tidept"]['data'][-1]

    root[angle_scan_id][i_angle]["frac_absorbed_TB"] = root['OUTPUTS'][gy_id]["torbeam"]["absorbed_power_fraction"]
    root[angle_scan_id][i_angle]["currf_TB"] = np.abs(root['OUTPUTS'][gy_id]['torbeam']["current_drive_efficiency"])
    root[angle_scan_id][i_angle]["rho_max_TB"] = root['OUTPUTS'][gy_id]['torbeam']["peak_absorption_rho"]
