# -*-Python-*-
# Created by meneghini at 2013/01/30 14:09
# Overhauled by S. Denk at 2021/08/26
# Explicit imports
from scipy.interpolate import InterpolatedUnivariateSpline
import numpy as np

defaultVars(
    ne_scale=1.0,
    fromMDS=False,
    skip=1,
    gEQDSK=root['INPUTS']['gEQDSK'],
    rho=root['DATA']['rho'],
    ne=root['DATA']['ne'],
    Te=root['DATA']['Te'],
)
device = tokamak(root['SETTINGS']['EXPERIMENT']['device'])
if 'ods' not in root['INPUTS']:
    root['INPUTS']['ods'] = ODS()
ods = root['INPUTS']['ods']
gEQDSK.to_omas(ods=ods, time_index=0, allow_derived_data=True)
if max(ne) > 1e15:
    ne = ne / 1.0e19
elif max(ne) > 1e10:
    ne = ne / 1.0e13
ne = ne_scale * ne
# TORBEAM does not like negative ne/Te
ne[ne < 1.0e-4] = 1.0e-4
Te[Te < 1.0e-5] = 1.0e-5
fmt = '%.8e'

# set ne Te files
for item in ['ne', 'Te']:
    with open(item + '.dat', 'w') as f:
        f.write(str(len(ne)) + '\n')
        tmp = vstack((rho, eval(item))).T
        savetxt(f, tmp, fmt=fmt)
    root['INPUTS'][item] = OMFITascii('./' + item + '.dat')

# Temperary solution to deal with dependency conflict
ne = ne / ne_scale
NR = len(ods["equilibrium.time_slice[0].profiles_2d[0].grid.dim1"][::skip])
NZ = len(ods["equilibrium.time_slice[0].profiles_2d[0].grid.dim2"][::skip])
# set topfile
with open('topfile', 'w') as f:
    f.write(device + ' ' + str(root['SETTINGS']['EXPERIMENT']['SHOT']) + ' ' + str(root['SETTINGS']['EXPERIMENT']['TIME']) + '\n')
    f.write(str(int(ceil(NR * 1.0 / skip))) + ' ' + str(int(ceil(NZ * 1.0 / skip))) + '\n')
    f.write('Dummy line\n')
    for i, val in enumerate(
        [
            min(ods["equilibrium.time_slice[0].profiles_2d[0].grid.dim1"]),
            max(ods["equilibrium.time_slice[0].profiles_2d[0].grid.dim1"]),
            1.0,
        ]
    ):
        f.write(("{0:" + fmt[1:] + "}").format(val))
        if i < 2:
            f.write(" ")
        else:
            f.write("\n")
    f.write('Grid: X-coordinates\n')
    savetxt(f, ods["equilibrium.time_slice[0].profiles_2d[0].grid.dim1"][::skip], fmt=fmt)
    f.write('Grid: Z-coordinates\n')
    savetxt(f, ods["equilibrium.time_slice[0].profiles_2d[0].grid.dim2"][::skip], fmt=fmt)
    f.write('Magnetic field: B_R\n')
    savetxt(f, ods["equilibrium.time_slice[0].profiles_2d[0].b_field_r"].T[::skip, ::skip], fmt=fmt)
    f.write('Magnetic field: B_t\n')
    savetxt(f, ods["equilibrium.time_slice[0].profiles_2d[0].b_field_tor"].T[::skip, ::skip], fmt=fmt)
    f.write('Magnetic field: B_Z\n')
    savetxt(f, ods["equilibrium.time_slice[0].profiles_2d[0].b_field_z"].T[::skip, ::skip], fmt=fmt)
    # NOTE: `Poloidal flux` has to be the square of the radial
    #        coordinate based on which the density and temperature
    #       profiles are defined. In this case `rho`.
    f.write('Poloidal flux: psi\n')
    # Use gEQDSK here because the  rho_tor -> rho_pol hybrid does not exist in IMAS
    savetxt(f, gEQDSK['AuxQuantities']['RHORZ'][::skip, ::skip] ** 2, fmt=fmt)
    f.write(str(len(ne)) + '\n')
    tmp = vstack((rho, ne, Te)).T
    savetxt(f, tmp, fmt=fmt)

root['INPUTS']['topfile'] = OMFITascii('topfile')

# update xrmaj and xrmin in input namelist
