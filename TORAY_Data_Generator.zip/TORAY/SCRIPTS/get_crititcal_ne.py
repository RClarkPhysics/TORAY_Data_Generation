# -*-Python-*-
# Created by mcclenaghanj at 05 Jul 2017  23:07

"""
This script gets the critical density
"""

defaultVars(time=root['SETTINGS']['EXPERIMENT']['time'], gyro=0)

# Get ne and Te index which cooresponds to t=time
i_ne = list(root['DATA_ALL']['times']).index(int(time))
i_te = list(root['DATA_ALL']['times']).index(int(time))

root['INPUTS']['gEQDSK'] = root['DATA_ALL']['gEQDSKs'][int(time)]
root['DATA']['ne'] = root['DATA_ALL']['ne'][i_ne]
root['DATA']['Te'] = root['DATA_ALL']['Te'][i_te]
root['DATA']['rho'] = root['DATA_ALL']['rho']

ne_up = 1.0
ne_down = 0.9

###### Stolen from feedTORAY #######

root['SCRIPTS']['generate_torayin'].runNoGUI()
# do a loop over the number of gyrotrons, pulling data from UFILE

root['SCRIPTS']['generate_psiin'].runNoGUI(make_eqdsk=False)
####################################

# Test that upper boundary on critical density is okay
while True:
    root['SCRIPTS']['generate_echin'].runNoGUI(ne_scale=ne_up, derq=root['DATA'], eqdsk=root['INPUTS']['gEQDSK'], gyrotron=gyro)
    root['SCRIPTS']['runTORAY'].runNoGUI()
    if root['OUTPUTS']['toray.nc']['tpowde']['data'][-1] < 0.1:
        break
    else:
        ne_down = ne_up
        ne_up += 0.5

# Find critical density
uncertainity = (ne_up - ne_down) / ne_up
while uncertainity > root['SETTINGS']['PHYSICS']['uncertainty']:
    ne_scale = 0.5 * (ne_up + ne_down)
    root['SCRIPTS']['generate_echin'].runNoGUI(ne_scale=ne_scale, derq=root['DATA'], eqdsk=root['INPUTS']['gEQDSK'], gyrotron=gyro)
    root['SCRIPTS']['runTORAY'].runNoGUI()
    if root['OUTPUTS']['toray.nc']['tpowde']['data'][-1] > 0.9:
        ne_down = ne_scale
    else:
        ne_up = ne_scale
    uncertainity = (ne_up - ne_down) / ne_up

root['OUTPUTS']['crit_density'] = 0.5 * (ne_up + ne_down) * root['DATA']['ne'][0]

if 'neline' in root['DATA']:
    root['OUTPUTS']['crit_density_line'] = root['OUTPUTS']['crit_density'] * root['DATA']['neline'] / root['DATA']['ne'][0]
else:
    root['OUTPUTS']['crit_density_line'] = None
