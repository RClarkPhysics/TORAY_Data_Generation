# -*-Python-*-
# Created by mcclenaghanj at 07 Nov 2017  23:04

from OMFITlib_functions import get_gyros

defaultVars(gyrotron=scratch.get('gyrotron', None), ne_scale=1)
if gyrotron is None:
    printe('Select the gyrotron first!')
    OMFITx.End()

runid = root['SETTINGS']['EXPERIMENT']['runid']

root['ANGLE_SCAN_FILES_' + gyrotron + '_' + runid] = OMFITcollection('')
root['OUTPUTS'] = OMFITtree('')

gyros, gyroNames = get_gyros()
igyrotron = gyros[gyroNames.index(gyrotron)]
root['SCRIPTS']['generate_torayin'].runNoGUI(gyrotron=igyrotron)
# do a loop over the number of gyrotrons, pulling data from UFILE

root['SCRIPTS']['generate_psiin'].runNoGUI(make_eqdsk=False)
tor_range = root['SETTINGS']['PHYSICS']['tor_range']
pol_range = root['SETTINGS']['PHYSICS']['pol_range']

POLS, TORS = meshgrid(pol_range, tor_range)
POLS = np.radians(array(POLS.flatten()) - 90.0)
TORS = np.radians(array(TORS.flatten()) - 180.0)
time = root['SETTINGS']['EXPERIMENT']['time'] / 1.0e3
ref_beam = root['INPUTS']['ods']['ec_launchers']["beam"][igyrotron]
ref_code_params = root['INPUTS']['ods']['ec_launchers']["code.parameters.beam"][igyrotron]
itime = np.argmin(np.abs(ref_beam['time']) - time)

root['INPUTS']['angle_scan_ods'] = angle_scan_ods = ODS()
angle_scan_ods["ec_launchers"]["beam"][0] = ref_beam
angle_scan_ods['ec_launchers.code.parameters'] = CodeParameters()
angle_scan_ods['ec_launchers.code.parameters']['beam'] = ODS()
angle_scan_ods["ec_launchers"]["code.parameters.beam"][0] = ref_code_params
angle_scan_ods["ec_launchers"]["beam"][0]['name'] = ref_beam['name'] + f"_angscan_{0}"
angle_scan_ods["ec_launchers"]["beam"][0]['identifier'] = ref_beam['identifier'] + f"_angscan_{0}"
angle_scan_ods["ec_launchers"]["beam"][0]['steering_angle_tor'][itime] = TORS[0]
angle_scan_ods["ec_launchers"]["beam"][0]['steering_angle_pol'][itime] = POLS[0]
for i_angle, (pol, tor) in enumerate(zip(POLS[1:].flatten(), TORS[1:].flatten())):
    angle_scan_ods["ec_launchers"]["beam"][i_angle + 1] = ref_beam
    angle_scan_ods['ec_launchers.code.parameters']['beam'][i_angle + 1] = ref_code_params
    angle_scan_ods["ec_launchers"]["beam"][i_angle + 1]['name'] = ref_beam['name'] + f"_angscan_{i_angle+1}"
    angle_scan_ods["ec_launchers"]["beam"][i_angle + 1]['identifier'] = ref_beam['identifier'] + f"_angscan_{i_angle+1}"
    angle_scan_ods["ec_launchers"]["beam"][i_angle + 1]['steering_angle_tor'][itime] = tor
    angle_scan_ods["ec_launchers"]["beam"][i_angle + 1]['steering_angle_pol'][itime] = pol

results = root['SCRIPTS']['run_toray_all_gyrotrons'].run(ec_launchers=angle_scan_ods["ec_launchers"])
root['SCRIPTS']['collect_angle_scan'].run(gyrotron=gyrotron, POLS=POLS, TORS=TORS, runid=runid)
