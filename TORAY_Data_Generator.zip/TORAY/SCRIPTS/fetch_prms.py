# -*-Python-*-
# Created by bgrierson at 24 Jun 2016  08:26
#
# this is an adaptation of what originally written for TRANSP
# the ECH data is loaded from MDS+ and saved in the format of a U-File
# the TORAY namelist that TRANSP would use is saved in root['OUTPUTS']['TORAY']

import OMFITlib_ufiles

defaultVars(verbose=True, use_fit=True, FFT_vars=['ECE', 'ECH'], doPlot=False, coord='C')
root['OUTPUTS']['TORAY'] = OMFITtree()
torpath = root['OUTPUTS']['TORAY']
root['UFILES'] = OMFITtree()
rf_shot = root['SETTINGS']['EXPERIMENT']['shot']
tr_shot = rf_shot


# Remove TORAY settings from UFILEs and namelist
def remove_toray():
    # Remove UFILEs
    for k in ['ECP', 'ECA', 'ECB']:
        if k in list(root['UFILES'].keys()):
            del root['UFILES'][k]
    # Remove UFILE pre and ext
    for k in ['PREECP', 'PREECA', 'PREECB', 'EXTECP', 'EXTECA', 'EXTECB']:
        if k in list(root['OUTPUTS']['TORAY'].keys()):
            del root['OUTPUTS']['TORAY'][k]
    OMFITx.End()


# ===========================
# Create TORAY namelist which must be further modified
# to allow for TORAY driven from namelist or UFILE
# Contians all placeholders and loaded with simple defaults
# ===========================
toray_txt = '''
 ! ELECTRON CYCLOTRON RESONANCE HEATING (TORAY)
 ! o Enable TORAY
 NLTORAY = .True.
 !
 ! o Number of antenas
 NANTECH = 2
 !
 ! o Time for each gyrotron turn-on (if not using UFILE)
 TECHON = 2*0.0
 !
 ! o Time for each gyrotron turn-off (if not using UFILE)
 TECHOFF = 2*10.0
 !
 ! o Each gyrotron power in Watts (if not using UFILE)
 POWECH = 2*5.0e5
 !
 ! o Each gyrotron frequency in Hz (if not using UFILE)
 FREQECH = 2*1.10e+11

 !
 ! o Major radius of each gyrotron source (cm)
 XECECH = 2*239.99
 !
 ! o Elevation above midplane of each gyrotron source (cm)
 ZECECH = 2*67.94
 !
 ! o Toroidal angle of gyrotron source (deg).
 !   Has no impact on axisymmetric plasma
 PHECECH = 0.0
 !
 ! o Polar launch angle of central ray (deg).  Zero is vertically up.
 THETECH = 125.0 124.0
 !
 ! o Azimuthal launch angle of central ray (deg).  Zero is +R major radius
 PHAIECH = 2*180.0
 !
 ! - Supplying power information via UFILE (set in TRDATA)
 !  o ECH Power UFILE
 PREECP='OMF'
 EXTECP='ECP'
 !
 !  o ECH Polar aiming angle UFILE
 PREECA='OMF'
 EXTECA='ECA'
 !
 !  o ECH Azimuthal aiming angle UFILE
 PREECB='OMF'
 EXTECB='ECB'
 !
 ! - Additional TORAY input variables
 !  o Number of radial TORAY zones
 NPROFTOR =  41
 !
 !  o TORAY timestep sets frequency of calls to TORAY (seconds)
 DTTOR = 0.010
 !
 !  o Damping model of each gyrotron source
 NDAMPECH = 2*8
 !
 !  o Number of rays for each gyrotron source
 NRAYECH = 2*30
 !
 !  o Fraction of RF power launched as O-mode
 RFMODECH = 2*0.0
 !
 !  o Divergence angle (deg) defined as half-angle half-power
 BHALFECH = 2*1.7
 !
 !  o Aspect ratio of beam (1.0 = circle)
 BSRATECH = 2*1.0
 !
 ! - Additional namelist parameters (TRANSP)
 !  o Anomalous multiplier for current drive efficiency (can be > 1.0)
 EFFECH = 2*1.0
 !
 ! - TRANSP namelist parameters for TORAY namelist
 !   Defaults should apply to DIII-D but some set here to be explicit
 !  o Harmonic number
 NHARMTOR = 2
 !
'''

# ========================
# Realize the namelist as a sub-namelist for TRANSP
# ========================
nml = OMFITtranspNamelist('toray.nml', fromString=toray_txt)
root['OUTPUTS']['TORAY'] = NamelistName()
root['OUTPUTS']['TORAY'].update(nml)
if source == 'namelist':
    printi('Driving TORAY from Namelist')
    remove_toray()

# Get ECH history to set namelist and UFILEs
# ECH on DIII-D is in MDSplus RF Tree RF.ECH
# We loop over the "systems" and find which ones were used and get their history.
# Power is always time dependent but aiming is only time-dependent if the mirrors
# were used for steering or tracking during the shot.
# The nodes SYSTEM_[] has the following
# SYSTEM_[].GYROTRON.NAME i.e. LEIA
# SYSTEM_[].GYROTRON.FREQUENCY i.e. 110e9 Hz
# SYSTEM_[].ANTENNA.LAUNCH_R is the R(m) of launcher for XECECH
# SYSTEM_[].ANTENNA.LAUNCH_Z is the Z(m) of launcher for ZECECH
# For gyrotron specifices then go to the tree of that gyrotron 3 char name
# ECH.LEIA.ECLEISTAT 0 for dummy load, 1 for tokamak
# ECH.LEIA.ECLEIFPWRC for time history of Leia forward power coupled (W)
# ECH.LEIA.ECLEIPOLANG for time history of Leia polar angle (deg)
# ECH.LEIA.ECLEIAZIANG for time history of Leia azimuthal angle (deg)
#
# DIII-D MDSplus RF Tree (161086 for real-time steering, 155196 for static aiming)

# Shot number for TRANSP UFILE
tr_shot = root['SETTINGS']['EXPERIMENT']['shot']
# Shot number for RF source passed in (allows getting ECH for one shot and inserting into another)
device = root['SETTINGS']['EXPERIMENT']['device']
tr_device = tokamak(device, output_style='TRANSP')
printi('Fetcing RF Tree')
rf = OMFITmds(server=device, shot=tr_shot, treename='RF')
shotdate = OMFITrdb(query='select * from summaries where shot=%d' % rf_shot, db='d3drdb')[0]['time_of_shot']

if 'ECH' not in rf:
    printe('No ECH tree this shot')
    remove_toray()

ech = rf['ECH']
ns = ech['NUM_SYSTEMS']
if ns.data() is None:
    printi('No ECH systems available')
    remove_toray()
else:
    num_systems = ns.data()[0]
printi(' Number of ECH Systems: {}'.format(num_systems))
# Re-format timebase to be on 0.1 ms (100k points for 10.0 seconds)
tbase = arange(0.0, 10000.1, 0.1)
# Threshold power for gyrotron to be "on"
thresh = 50e3
# Dictionary of gyrotron information
echdict = SortedDict()
for i in range(1, num_systems + 1, 1):
    system = ech['SYSTEM_{}'.format(i)]
    # Full name
    name = system['GYROTRON']['NAME'].data()[0]
    # Short name for power, angles, etc...
    sname = name[0:3].upper()
    printi('-Fetching data for {} ({})'.format(name, sname))

    # Frequency (Hz)
    freq = system['GYROTRON']['FREQUENCY'].data()[0]

    # Launcher (R,Z) in meters
    launch_r = system['ANTENNA']['LAUNCH_R'].data()[0]
    launch_z = system['ANTENNA']['LAUNCH_Z'].data()[0]

    # Gyrotron specific tree for status and angles
    gyro = ech['{}'.format(name.upper())]
    status = gyro['EC{}STAT'.format(sname)].data()[0]
    if status == 0:
        printi('  Fired into dummy load')
        break
    elif status == 1:
        printi('  Fired into tokamak')
    else:
        printe('  Unknown firing status')
        OMFITx.End()

    # Polar angle (degrees)
    tpang = gyro['EC{}POLANG'.format(sname)].dim_of(0)
    pang = gyro['EC{}POLANG'.format(sname)].data()
    if np.all(pang == pang[0]):
        printi('  Time-independent polar mirror steering')
        polang = pang[0]
    else:
        printi('  Time-dependent polar mirror steering')
        polang = pang

    # Azimuthal angle (degrees)
    taang = gyro['EC{}AZIANG'.format(sname)].dim_of(0)
    aang = gyro['EC{}AZIANG'.format(sname)].data()
    if np.all(aang == aang[0]):
        printi('  Time-independent azimuthal mirror steering')
        aziang = aang[0]
    else:
        printi('  Time-dependent azimuthal mirror steering')
        aziang = aang

    # Power coupled into tokamak (W)
    fpwrc = gyro['EC{}FPWRC'.format(sname)]
    time = fpwrc.dim_of(0)
    power = fpwrc.data()
    mask = power > thresh
    if np.sum(mask) > 0:
        powerc = power
        powerc[~mask] *= 0.0
        pavg = np.mean(powerc[mask])
        ton = np.min(time[mask])
        toff = np.max(time[mask])
        printi('  t On:{0:0.2f} ms'.format(ton))
        printi('  t Off:{0:0.2f} ms'.format(toff))
        printi('  <Pinj>:{0:0.2f} MW'.format(pavg * 1e-6))

        # Form dictionary for this gyrotron
        gdict = SortedDict()
        gdict['NAME'] = name
        gdict['SNAME'] = sname
        gdict['FREQ'] = freq
        gdict['LAUNCH_R'] = launch_r
        gdict['LAUNCH_Z'] = launch_z
        if isinstance(polang, np.ndarray):
            gdict['POLANG'] = interpolate.interp1d(tpang, polang, bounds_error=False)(tbase)
        else:
            gdict['POLANG'] = polang
        if isinstance(aziang, np.ndarray):
            gdict['AZIANG'] = interpolate.interp1d(taang, aziang, bounds_error=False)(tbase)
        else:
            gdict['AZIANG'] = aziang
        gdict['TON'] = ton
        gdict['TOFF'] = toff
        gdict['PAVG'] = pavg
        gdict['POWER'] = interpolate.interp1d(time, powerc, bounds_error=False)(tbase)

        # Add this gyrotron to the ECH dictionary
        echdict['{}'.format(name)] = gdict
    else:
        printe('  Gyrotron {0:s} exists in SYSTEM_{1:d} but reports no power'.format(name, i))

# Check if steering was enabled for any gyrotron
steering = False
for g in echdict:
    if isinstance(echdict[g]['POLANG'], np.ndarray) or isinstance(echdict[g]['AZIANG'], np.ndarray):
        steering = True

# Get total power from ECH to verify
echpwrc = ech['TOTAL']['ECHPWRC']
time = echpwrc.dim_of(0)
power = echpwrc.data()
mask = power > thresh
if np.sum(mask) > 0:
    powerc = +power
    powerc[~mask] *= 0.0
    pavg = np.mean(powerc[mask])
    ton = np.min(time[mask])
    toff = np.max(time[mask])

    # Form dictionary for this total power
    tdict = SortedDict()
    tdict['TON'] = ton
    tdict['TOFF'] = toff
    tdict['PAVG'] = pavg
    tdict['POWER'] = interpolate.interp1d(time, powerc, bounds_error=False)(tbase)

# Store ECH dictionary for inspection and debug
scratch['ECHDICT'] = echdict
# Get number of gyrotrons and test if any are used
ngyro = len(echdict)
if ngyro == 0:
    printi('No gyrotrons')
    # Remove UFILEs
    for k in ['ECP', 'ECA', 'ECB']:
        if k in list(root['UFILES'].keys()):
            del root['UFILES'][k]
    # Remove TORAY
    if 'TORAY' in list(root['OUTPUTS'].keys()):
        del root['OUTPUTS']['TORAY']
    OMFITx.End()
else:
    # ========================
    # Realize the namelist in scratch as a sub-namelist for TRANSP
    # ========================
    # transp = OMFITtranspNamelist('transp.template',fromString='! TRANSP Template\n! BEGIN\n')
    # scratch['TRANSP'] = transp
    nml = OMFITtranspNamelist('toray.nml', fromString=toray_txt)
    root['OUTPUTS']['TORAY'] = NamelistName()
    root['OUTPUTS']['TORAY'].update(nml)


tonmin = np.min(np.array([echdict[i]['TON'] for i in echdict]))
toffmax = np.max(np.array([echdict[i]['TOFF'] for i in echdict]))

# ===============================
# Fill out TRANSP/TORAY Namelist
# ===============================
root['OUTPUTS']['TORAY']['NANTECH'] = ngyro

techon = [echdict[i]['TON'] for i in echdict]
root['OUTPUTS']['TORAY']['TECHON'] = np.array(techon) * 1e-3
# for i,val in enumerate(techon):
#     root['OUTPUTS']['TORAY']['TECHON({})'.format(i)] = val*1e-3

techoff = [echdict[i]['TOFF'] for i in echdict]
root['OUTPUTS']['TORAY']['TECHOFF'] = np.array(techoff) * 1e-3

powech = [echdict[i]['PAVG'] for i in echdict]
root['OUTPUTS']['TORAY']['POWECH'] = np.array(powech)

freqech = [echdict[i]['FREQ'] for i in echdict]
root['OUTPUTS']['TORAY']['FREQECH'] = np.array(freqech)

xecech = [echdict[i]['LAUNCH_R'] * 1e2 for i in echdict]
root['OUTPUTS']['TORAY']['XECECH'] = np.array(xecech)

zecech = [echdict[i]['LAUNCH_Z'] * 1e2 for i in echdict]
root['OUTPUTS']['TORAY']['ZECECH'] = np.array(zecech)

names = [echdict[i]['NAME'] for i in echdict]
root['OUTPUTS']['TORAY']['NAME'] = np.array(name)

thetaech = np.zeros(ngyro)
phaiech = np.zeros(ngyro)
for i, g in enumerate(echdict.keys()):
    if isinstance(echdict[g]['POLANG'], np.ndarray):
        thetaech[i] = echdict[g]['POLANG'][0]
    else:
        thetaech[i] = echdict[g]['POLANG']
    if isinstance(echdict[g]['AZIANG'], np.ndarray):
        phaiech[i] = echdict[g]['AZIANG'][0]
    else:
        phaiech[i] = echdict[g]['AZIANG']
root['OUTPUTS']['TORAY']['THETECH'] = thetaech
root['OUTPUTS']['TORAY']['PHAIECH'] = phaiech
if not steering:
    del root['OUTPUTS']['TORAY']['PREECA']
    del root['OUTPUTS']['TORAY']['EXTECA']
    del root['OUTPUTS']['TORAY']['PREECB']
    del root['OUTPUTS']['TORAY']['EXTECB']


root['OUTPUTS']['TORAY']['NDAMPECH'] = np.repeat(8, ngyro)
root['OUTPUTS']['TORAY']['NRAYECH'] = np.repeat(30, ngyro)
root['OUTPUTS']['TORAY']['RFMODECH'] = np.repeat(0.0, ngyro)
root['OUTPUTS']['TORAY']['BHALFECH'] = np.repeat(1.7, ngyro)
root['OUTPUTS']['TORAY']['BSRATECH'] = np.repeat(1.0, ngyro)
root['OUTPUTS']['TORAY']['EFFECH'] = np.repeat(1.0, ngyro)

# ================
# Form ECH UFILEs.  Store data for min(TECHON)-100 to max(TECHOFF)+100
# ================
gi = arange(1, ngyro + 1, 1)
tmin = tonmin - 100
tmax = toffmax + 100
mask = (tbase > tmin) * (tbase < tmax)
pinj = np.zeros((np.sum(mask), ngyro))
namearr = []
tpinj = tbase[mask]
for i, g in enumerate(echdict.keys()):
    namearr.append(echdict[g]['NAME'])
    pinj[:, i] = echdict[g]['POWER'][mask]
ecp = OMFITlib_ufiles.createECUFILE(tpinj * 1e-3, gi, pinj, tr_device, tr_shot, shotdate, ext='ECP', comment='DIII-D ECH RF.ECH')
# root['OUTPUTS']['TORAY']['ecp']= ecp
root['UFILES']['ECP'] = ecp
root['UFILES']['ECP']['NAMES'] = namearr

# Form gyrotron mirror steering UFILEs if needed
if steering:
    polang = np.zeros((np.sum(mask), ngyro))
    aziang = np.zeros((np.sum(mask), ngyro))
    for i, g in enumerate(echdict.keys()):
        if isinstance(echdict[g]['POLANG'], np.ndarray):
            polang[:, i] = echdict[g]['POLANG'][mask]
        else:
            polang[:, i] = np.repeat(echdict[g]['POLANG'], np.sum(mask))
        if isinstance(echdict[g]['AZIANG'], np.ndarray):
            aziang[:, i] = echdict[g]['AZIANG'][mask]
        else:
            aziang[:, i] = np.repeat(echdict[g]['AZIANG'], np.sum(mask))
    eca = OMFITlib_ufiles.createECUFILE(tpinj * 1e-3, gi, polang, tr_device, tr_shot, shotdate, ext='ECA', comment='DIII-D ECH RF.ECH')
    ecb = OMFITlib_ufiles.createECUFILE(tpinj * 1e-3, gi, aziang, tr_device, tr_shot, shotdate, ext='ECB', comment='DIII-D ECH RF.ECH')
    eca['F']['name'] = 'ECH POLAR ANGLE'
    ecb['F']['name'] = 'ECH AZI ANGLE'
    eca['F']['units'] = 'DEG'
    ecb['F']['units'] = 'DEG'
    root['UFILES']['ECA'] = eca
    root['UFILES']['ECB'] = ecb


# First time dependent and aiming data then profiles if they exist
if is_localhost('iris'):
    filepath = '/fusion/pillar-archive/u/brookmanmw/toray/'
else:
    print('Not on supported server')
    OMFITx.End()

# This branch can load reference files for comparison
if ~False and ('NLTORAY' in torpath):
    filepaths = filepath + '' + str(rf_shot) + '/'
    print('Loading All Files in ' + filepaths)
    torprofs = []
    timepf = []
    for filen in os.listdir(filepaths):
        if filen.endswith(".sav"):
            torprofs.append(filen)

            timepf.append(filen.split('.')[1])
    print(torprofs)
    print(timepf)
    if len(torprofs) >= 1:

        tmp = []
        for fd, fl in enumerate(torprofs):
            stime = timepf[fd]
            tmp.append(OMFITidlSav(filepaths + fl))
        root['OUTPUTS']['TORAY'] = OMFITtree()
        root['OUTPUTS']['TORAY']['profs'] = tmp
    else:
        print('No files found in ' + filepaths)
if not doPlot:
    OMFITx.End()

# ================
# Plot data from MDSplus as well as data that ended up in UFILE
# ================
fig, ax = plt.subplots(nrows=int(np.ceil(np.sqrt(ngyro))), ncols=int(np.ceil(np.sqrt(ngyro))), sharex=True)
axf = ax.flatten()
for i, g in enumerate(echdict.keys()):
    axf[i].plot(tbase, echdict[g]['POWER'], label=echdict[g]['NAME'])
    xl = axf[i].get_xlim()
    yl = axf[i].get_ylim()
    axf[i].hlines(thresh, xl[0], xl[1], color='black', linestyle='dashed')
    axf[i].vlines(tonmin, 0.0, yl[1], color='black', linestyle='dashed')
    axf[i].vlines(toffmax, 0.0, yl[1], color='black', linestyle='dashed')
    axf[i].legend()

# Plot all data together and UFILE data
fig, ax = plt.subplots(nrows=2)
ptot = np.zeros(len(tbase))
for g in echdict:
    ax[0].plot(tbase, echdict[g]['POWER'], label=echdict[g]['NAME'])
    ptot = ptot + echdict[g]['POWER']
yl = ax[0].get_ylim()
ax[0].plot(tbase, ptot, label='SUM')
ax[0].vlines(tonmin, 0, yl[1], color='black', linestyle='dashed')
ax[0].vlines(toffmax, 0, yl[1], color='black', linestyle='dashed')
ax[0].plot(tbase, tdict['POWER'], label='ECHPWRC', marker='o', alpha=0.1, linestyle='None')
ax[0].legend()
ax[0].set_title('ECH Data')
# Plot the UFILE
for i in range(root['UFILES']['ECP']['SCALARS'][0]['data']):
    ax[1].plot(root['UFILES']['ECP']['X0']['data'], root['UFILES']['ECP']['F']['data'][:, i])
yl = ax[1].get_ylim()
ax[1].vlines(np.min(root['UFILES']['ECP']['X0']['data']), 0, yl[1], color='black', linestyle='dashed')
ax[1].vlines(np.max(root['UFILES']['ECP']['X0']['data']), 0, yl[1], color='black', linestyle='dashed')
ax[1].set_title('UFILE Data')
ax[1].set_xlabel('{} ({})'.format(root['UFILES']['ECP']['X0']['name'], root['UFILES']['ECP']['X0']['units']))
ax[1].set_ylabel('{} ({})'.format(root['UFILES']['ECP']['F']['name'], root['UFILES']['ECP']['F']['units']))

# Plot steering if it was used
if steering:
    fig, ax = plt.subplots(nrows=int(np.ceil(np.sqrt(ngyro))), ncols=int(np.ceil(np.sqrt(ngyro))), sharex=True)
    axf = ax.flatten()
    for i in range(root['UFILES']['ECA']['SCALARS'][0]['data']):
        axf[i].plot(root['UFILES']['ECA']['X0']['data'], root['UFILES']['ECA']['F']['data'][:, i])
        yl = axf[i].get_ylim()
        axf[i].vlines(np.min(root['UFILES']['ECA']['X0']['data']), yl[0], yl[1], color='black', linestyle='dashed')
        axf[i].vlines(np.max(root['UFILES']['ECA']['X0']['data']), yl[1], yl[1], color='black', linestyle='dashed')
        axf[i].set_title('UFILE Polar Data')
        axf[i].set_xlabel('{} ({})'.format(root['UFILES']['ECA']['X0']['name'], root['UFILES']['ECA']['X0']['units']))
        axf[i].set_ylabel('{} ({})'.format(root['UFILES']['ECA']['F']['name'], root['UFILES']['ECA']['F']['units']))

    fig, ax = plt.subplots(nrows=int(np.ceil(np.sqrt(ngyro))), ncols=int(np.ceil(np.sqrt(ngyro))), sharex=True)
    axf = ax.flatten()
    for i in range(root['UFILES']['ECB']['SCALARS'][0]['data']):
        axf[i].plot(root['UFILES']['ECB']['X0']['data'], root['UFILES']['ECB']['F']['data'][:, i])
        yl = axf[i].get_ylim()
        axf[i].vlines(np.min(root['UFILES']['ECB']['X0']['data']), yl[0], yl[1], color='black', linestyle='dashed')
        axf[i].vlines(np.max(root['UFILES']['ECB']['X0']['data']), yl[1], yl[1], color='black', linestyle='dashed')
        axf[i].set_title('UFILE Azimuthal Data')
        axf[i].set_xlabel('{} ({})'.format(root['UFILES']['ECB']['X0']['name'], root['UFILES']['ECB']['X0']['units']))
        axf[i].set_ylabel('{} ({})'.format(root['UFILES']['ECB']['F']['name'], root['UFILES']['ECB']['F']['units']))
