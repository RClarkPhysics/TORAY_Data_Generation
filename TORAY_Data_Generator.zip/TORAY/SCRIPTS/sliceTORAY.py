# -*-Python-*-
# Created by brookmanmw at 14 Feb 2017  10:28
ecp = root['UFILES']['ECP']
torp = root['OUTPUTS']['TORAY']
tarr = root['SETTINGS']['EXPERIMENT']['times']
tmp = root['OUTPUTS']['TORAYarr']
dexs = root['OUTPUTS']['dexs']
xr = arange(200)
for sldex, sltime in enumerate(tarr):
    for gdex, gname in enumerate(ecp['NAMES']):
        numar = gdex + sldex * len(tarr)
        tordat = {}
        tordat['rho'] = DataArray(
            tmp[numar]['xmrho']['data'], coords={'channel': xr, 'gyrotron': [gname], 'time': [sltime]}, attrs={'units': 'W/cm**3'}
        )
        tordat['p_ECH_per_W'] = DataArray(
            tmp[numar]['weecrh']['data'], coords={'channel': xr, 'gyrotron': [gname], 'time': [sltime]}, attrs={'units': 'W/cm**3'}
        )
        # tordat['J_ECCD_perW']=
        # tordat['Int_p']=
        # tordata['Int_J']=
