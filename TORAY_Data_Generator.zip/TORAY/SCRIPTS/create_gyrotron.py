defaultVars(gyro_name='TRON')


ods = root['INPUTS']['ods']

print('Set parameters inside of the script!')

# make a new launcher from the last one
n = len(ods['ec_launchers.beam'])
ods['ec_launchers.beam'][n] = copy.deepcopy(ods['ec_launchers.beam'][-1])
new_launcher = ods['ec_launchers.beam'][n]
new_launcher['identifier'] = gyro_name

new_launcher['frequency.data'] = [110e9]
new_launcher['frequency.time'] = [0.0]

new_launcher['launching_position.phi'] = [-1.57]
new_launcher['launching_position.r'] = [2.4]
# in this case it is a midplane launcher
new_launcher['launching_position.z'] = [0.0]

new_launcher['mode'] = -1  # 1 for O-mode, -1 for X-mode
new_launcher['name'] = gyro_name

new_launcher['phase.angle'] = [0.0]
new_launcher['phase.curvature'] = [[0.0], [0.0]]

new_launcher['power_launched.data'] = [8e5]
new_launcher['power_launched.time'] = [1.5]

new_launcher['spot.angle'] = [0.0]
new_launcher['spot.size'] = [[0.0172], [0.0172]]

angle_pol = 90
new_launcher['steering_angle_pol'] = [np.radians(angle_pol - 90)]
angle_tor = 180
new_launcher['steering_angle_tor'] = [np.radians(angle_tor - 180.0)]
new_launcher['time'] = [1.5]

code = copy.deepcopy(ods['ec_launchers.code.parameters']['beam'][n - 1])
code['ON'] = 1
code['mharm'] = 2
ods['ec_launchers.code.parameters']['beam'][n] = code
