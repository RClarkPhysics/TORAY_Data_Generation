# -*-Python-*-
# Created by meneghini at 01 Mar 2017  14:43

# it does not work without the 'toray.in' file
torayin = root['INPUTS']['toray.in']
root['INPUTS'].clear()
root['INPUTS']['toray.in'] = torayin

root['OUTPUTS'].clear()
root['UFILES'].clear()
