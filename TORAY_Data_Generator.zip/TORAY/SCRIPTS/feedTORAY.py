# -*-Python-*-
# Created by brookmanmw at 07 Feb 2017  08:56
#
# run TORAY for each time slice, for each gyrotron

# 0th step - fetch EFIT needed

# first step - torayin can be generated once
root['SCRIPTS']['generate_torayin'].runNoGUI()
root['SCRIPTS']['fetch_prms'].runNoGUI()

# do a loop over the number of gyrotrons, pulling data from UFILE

ecp = root['UFILES']['ECP']
torp = root['OUTPUTS']['TORAY']
tarr = root['SETTINGS']['EXPERIMENT']['times']

root['OUTPUTS']['TORAYout'] = tmp = OMFITcollection()
root['OUTPUTS']['dexs'] = dexs = []
infos = []

for sldex, sltime in enumerate(tarr):
    root['SETTINGS']['slnum'] = sldex
    root['SCRIPTS']['generate_psiin'].runNoGUI()
    print(sldex)
    tmp[sltime] = OMFITcollection()
    for gdex, gname in enumerate(ecp['NAMES']):
        root['SETTINGS']['gnum'] = gdex
        dexpair = (sldex, gdex)
        infopair = (sltime, gname)
        dexs.append(dexpair)
        infos.append(infopair)
        # need to regenerate echin for each gyrotron
        root['SCRIPTS']['generate_echin'].runNoGUI()
        root['SCRIPTS']['runTORAY'].runNoGUI()
        tmp[sltime][gname] = root['OUTPUTS']['toray.nc']
