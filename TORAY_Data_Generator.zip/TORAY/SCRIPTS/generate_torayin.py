# -*-Python-*-
# Created by brookmanmw at 03 Jan 2017  13:16

defaultVars(gyrotron=0)

root['INPUTS']['toray.in']['EDATA']['nharm'] = root['INPUTS']['ods']['ec_launchers.code.parameters.beam'][gyrotron]['mharm']

printi('Updated `torayin` harmonic.')
