# -*-Python-*-
# Created by meneghini at 25 Nov 2016  21:33
#
# run TORAY using the input files in root['INPUTS']

root['INPUTS']['toray.in'].collect_arrays = False
root['INPUTS']['toray.in'].compress_arrays = False
root['INPUTS']['toray.in'].explicit_arrays = True

OMFITx.executable(root, inputs=list(root['INPUTS'].values()), outputs=['toray.nc'])

root['OUTPUTS']['toray.nc'] = OMFITnc('./toray.nc')
