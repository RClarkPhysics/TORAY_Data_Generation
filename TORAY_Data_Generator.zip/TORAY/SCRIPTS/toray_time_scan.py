# -*-Python-*-
# Created by mcclenaghanj at 06 Jul 2017  00:37

from OMFITlib_functions import get_gyros

defaultVars(temperature_scale=1.0)

root['OUTPUTS'].clear()
root['SCAN_FILES'].clear()

if root['SETTINGS']['PHYSICS']['inputDATA'] == 'ZIPFITs':
    root['SCRIPTS']['get_zipfit_time_data'].run()
elif root['SETTINGS']['PHYSICS']['inputDATA'] in ['kineticEFITtime', 'OMFITprofiles', 'QUICKFIT']:
    root['SCRIPTS']['get_OMFITprofiles_time_data'].run()
else:
    printe('No time data available for this Input Data')
    OMFITx.End()

    if root['SETTINGS']['SETUP']['updateGyrotrons']:
        root['SCRIPTS']['fetchGyrotronsData'].run(time=time)
if root['SETTINGS']['SETUP']['runType'] == 'Time dependent critical ne':

    gyros, gyroNames = get_gyros()
    for i, time in enumerate(root['DATA_ALL']['times']):

        if root['SETTINGS']['SETUP']['updateGyrotrons']:
            root['SCRIPTS']['fetchGyrotronsData'].run(time=time)

        root['OUTPUTS'].clear()
        root['DATA']['rho'] = root['DATA_ALL']['rho']
        root['DATA']['Te'] = root['DATA_ALL']['Te'][i]
        root['DATA']['ne'] = root['DATA_ALL']['ne'][i]
        root['INPUTS']['gEQDSK'] = root['DATA_ALL']['gEQDSKs'][int(time)]

        if 'neline' in root['DATA_ALL']:
            root['DATA']['neline'] = root['DATA_ALL']['neline'][i]

        results = root['SCRIPTS']['get_critical_ne'].prun(
            len(gyros),
            len(gyros),
            'results',
            gyro=gyros,
            time=time * ones(len(gyros)),
            runIDs=gyroNames,
            postrun="results={'ne':root['OUTPUTS']['crit_density'],'neline':root['OUTPUTS']['crit_density_line']}",
        )
        root['SCAN_FILES'][time] = results
        root['SCAN_FILES'][time]['ods'] = copy.deepcopy(root['INPUTS']['ods'])

else:
    for i, time in enumerate(root['DATA_ALL']['times']):
        if root['SETTINGS']['SETUP']['updateGyrotrons']:
            root['SCRIPTS']['fetchGyrotronsData'].run(time=time)

        root['OUTPUTS'].clear()
        root['DATA']['rho'] = root['DATA_ALL']['rho']
        root['DATA']['Te'] = root['DATA_ALL']['Te'][i]
        root['DATA']['ne'] = root['DATA_ALL']['ne'][i]
        root['INPUTS']['gEQDSK'] = root['DATA_ALL']['gEQDSKs'][int(time)]

        if 'neline' in root['DATA_ALL']:
            root['DATA']['neline'] = root['DATA_ALL']['neline'][i]
        root['SCRIPTS']['generate_topfile'].run()
        root['SCRIPTS']['run_toray_all_gyrotrons'].run()
        root['SCAN_FILES'][time] = copy.deepcopy(root['OUTPUTS'])
        root['SCAN_FILES'][time]['ods'] = copy.deepcopy(root['INPUTS']['ods'])
