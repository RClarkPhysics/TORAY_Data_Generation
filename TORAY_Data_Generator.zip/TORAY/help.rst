Short Description
-----------------
Run the TORAY ray,-tracing code for ECH waves and the TORBEAM beam tracing code

Keywords
--------
ray-tracing, paraxial, ECH, beam-tracing

Long Description
----------------
The TORAY code is an adaptation to tokamak geometry of earlier work done for mirror geometry.
TORAY uses the cold plasma dispersion relation for the ray tracing and various models may be chosen for the absorption.
For ECCD, TORAY may use the adjoint approach specialized to ECCD by Cohen.
The Cohen approach has been reworked by Lin-Liu to generalize the square magnetic well used in Cohen’s approach.
In a third version of the ECCD calculation, Lin-Liu has added the effect of the wave polarization calculated from an
externally evaluated dispersion relation rather than the approximation that the wave is right-hand circularly polarized,
a condition that is not even approximately true for the ordinary mode as in the ITER design.

This module has been setup to automatically run the beam-tracing code TORBEAM in addition to TORAY. This feature has been
tested for the primary workflow loop of running a single time point for all gyrotrons and the multi-time workflow.

Typical workflows
-----------------
This module is used to:

Setup profiles from ODS, OMFITprofiles, ZIPFITs, PRO_create, kineticEFITtime

Setup gyrotrons for a given shot and time.

Edit gyrotrons aiming if desired.

Run TORAY:
   As stand-alone
   For entire shot
   Find critical density of entire shot
   Scan Density
   Scan Angle

Tutorials
---------
* TORAY tutorial (`Google docs <https://docs.google.com/document/d/1MmyBw-Xb0LzQL_Kh-Rc92OvpoK9GqWNdgLe5wCq5NIw>`_ , `PDF <https://docs.google.com/document/d/1MmyBw-Xb0LzQL_Kh-Rc92OvpoK9GqWNdgLe5wCq5NIw/export?format=pdf>`_)

Supported devices
-----------------
* Device agnostic

Relevant publications
---------------------
* `Prater, R., et al. "Benchmarking of codes for electron cyclotron heating and electron cyclotron current drive under ITER conditions." Nuclear Fusion 48.3 (2008): 035006. <http://iopscience.iop.org/article/10.1088/0029-5515/48/3/035006/meta>`_
* `Poli, Emanuele, et al. "TORBEAM 2.0, a paraxial beam tracing code for electron-cyclotron beams in fusion plasmas for extended physics applications." Computer Physics Communications 225 (2018): 36-46.`
.. code-block:: none
