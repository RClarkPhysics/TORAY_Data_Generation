# -*-Python-*-
# Created by bgrierson at 02 Jun 2016  12:08

# Function to fill 1D history U-file
def createHistoryUFILE(x, y, device, shot, date, pre, ext, name, units, comment=''):
    """
    :param x: Time in seconds (1d numpy array)

    :param y: Data (1d numpy array)

    :param device: Machine i.e. 'D3D'

    :param shot: Shot number i.e. 123456

    :param date: Date of shot i.e. '21Dec-1980' or python datetime object

    :param pre: UFILE prefix i.e. 'OMF' for creation with OMFIT

    :param ext: UFILE extension i.e. 'CUR' for plasma current

    :param name: Variable name i.e. 'Plasma Current'

    :param units: Variable Units i.e. 'Amps'

    :param comment: comment to be added to UFILE

    :return: OMFIT UFILE data object
    """

    # Default to processing code: raw
    proc = 0
    if isinstance(date, datetime):
        shotdate = date.strftime('%d%b-%Y')
    else:
        shotdate = date

    # create a new ufile and fill it with data
    if os.path.exists('{}{:}.{:}'.format(pre, shot, ext)):
        os.remove('{}{:}.{:}'.format(pre, shot, ext))
    ufile = OMFITuFile('{}{:}.{:}'.format(pre, shot, ext))
    ufile['F'] = {'name': name, 'units': units, 'data': y}
    ufile['X0'] = {'name': 'TIME', 'units': 'SEC', 'data': x}
    ufile['SHOT'] = int(shot)
    ufile['DEVICE'] = device
    ufile['NDIM'] = len(ufile['F']['data'].shape)
    ufile['COMPRESSION'] = 0
    ufile['LSHOT'] = len(str(int(shot)))
    ufile['PROCESSING_CODE'] = proc
    ufile['DATE'] = shotdate
    ufile['COMMENTS'] = ['Written by {:} using OMFIT'.format(os.environ['USER'])]
    if comment != '':
        ufile['COMMENTS'].append(comment)

    return ufile


# Function to fill 2D profiles U-file
def createProfileUFILE(x, y, z, device, shot, date, pre, ext, name, units, comment=''):
    """
    :param x: Radial coordinate default sqrt. norm. tor. flux (1d numpy array)

    :param y: Time in seconds (1d numpy array)

    :param z: Data in space, time (2d numpy array)

    :param device: Machine i.e. 'D3D'

    :param shot: Shot number i.e. 123456

    :param date: Date of shot i.e. '21Dec-1980' or python datetime object

    :param pre: UFILE prefix i.e. 'OMF' for creation with OMFIT

    :param ext: UFILE extension i.e. 'NEL' for electron density

    :param name: Variable name i.e. 'Electron density'

    :param units: Variable Units i.e. 'M**-3'

    :param comment: comment to be added to UFILE

    :return: OMFIT UFILE data object
    """

    # Default to processing code: raw
    proc = 0

    if isinstance(date, datetime):
        shotdate = date.strftime('%d%b-%Y')
    else:
        shotdate = date

    # Create new UFILE and fill with data
    if os.path.exists('{}{:}.{:}'.format(pre, shot, ext)):
        os.remove('{}{:}.{:}'.format(pre, shot, ext))
    ufile = OMFITuFile('{}{}.{}'.format(pre, shot, ext))
    # The function
    ufile['F'] = {'name': name, 'units': units, 'data': z}
    ufile['X0'] = {'name': 'X', 'units': '', 'data': x}
    ufile['X1'] = {'name': 'TIME', 'units': 'SEC', 'data': y}
    ufile['SHOT'] = int(shot)
    ufile['DEVICE'] = device
    ufile['NDIM'] = len(ufile['F']['data'].shape)
    ufile['COMPRESSION'] = 0
    ufile['LSHOT'] = len(str(shot))
    ufile['PROCESSING_CODE'] = proc
    ufile['DATE'] = shotdate
    ufile['COMMENTS'] = ['Written by {:} using OMFIT'.format(os.environ['USER'])]
    if comment != '':
        ufile['COMMENTS'].append(comment)

    return ufile


# Function to fill 2D NUBEAM U-file
def createNUBEAMUFILE(x, y, z, device, shot, date, pre='OMF', ext='NB2', comment=''):
    """
    :param x: Beam data index (1, ..., 4*number of beams)

    :param y: Time in seconds (1d numpy array)

    :param z: Data in beam index, time (2d numpy array)
              Note beam data is order by power, voltage, full current, half current
              where power is power(ib,time), power(ib+1, time) ... followed by voltage...

    :param device: Machine i.e. 'D3D'

    :param shot: Shot number i.e. 123456

    :param date: Date of shot i.e. '21Dec-1980' or python datetime object

    :param pre: UFILE prefix i.e. 'OMF' for creation with OMFIT

    :param ext: UFILE extension i.e. 'NBI' for neutral beam injection

    :param name: Variable name i.e. 'Mixed Beam Data'

    :param units: Variable Units i.e. 'Mixed'

    :param comment: comment to be added to UFILE

    :return: OMFIT UFILE data object
    """

    # Default to processing code: raw
    proc = 0

    if isinstance(date, datetime):
        shotdate = date.strftime('%d%b-%Y')
    else:
        shotdate = date

    # Create new UFILE and fill with data
    if os.path.exists('{}{:}.{:}'.format(pre, shot, ext)):
        os.remove('{}{:}.{:}'.format(pre, shot, ext))
    ufile = OMFITuFile('{}{}.{}'.format(pre, shot, ext))
    # The function
    ufile['F'] = {'name': 'MIXED BEAM DATA', 'units': 'MIXED', 'data': z}
    ufile['X0'] = {'name': 'TIME', 'units': 'SEC', 'data': x}
    ufile['X1'] = {'name': 'CHANNEL NO', 'units': '', 'data': y}
    ufile['SCALARS'][0] = {'name': 'NBEAM', 'desc': '# OF BEAMS', 'data': len(y) // 4}
    ufile['SHOT'] = int(shot)
    ufile['DEVICE'] = device
    ufile['NDIM'] = len(ufile['F']['data'].shape)
    ufile['COMPRESSION'] = 0
    ufile['LSHOT'] = len(str(shot))
    ufile['PROCESSING_CODE'] = proc
    ufile['DATE'] = shotdate
    ufile['COMMENTS'] = ['Written by {:} using OMFIT'.format(os.environ['USER'])]
    if comment != '':
        ufile['COMMENTS'].append(comment)

    return ufile


# Function to fill 2D ECH Power/polar/azimuthal U-file
def createECUFILE(x, y, z, device, shot, date, pre='OMF', ext='ECP', comment=''):
    """
    :param x: Gyrotron index beginning with one

    :param y: Time in seconds (1d numpy array)

    :param z: Data in gyrotron index, time (2d numpy array)
              Note gyrotron data is power in Watts
              or polar angle in degrees
              or azimuthal angle in degrees

    :param device: Machine i.e. 'D3D'

    :param shot: Shot number i.e. 123456

    :param date: Date of shot i.e. '21Dec-1980' or python datetime object

    :param pre: UFILE prefix i.e. 'OMF' for creation with OMFIT

    :param ext: UFILE extension i.e. 'NBI' for neutral beam injection

    :param name: Variable name i.e. 'Mixed Beam Data'

    :param units: Variable Units i.e. 'Mixed'

    :param comment: comment to be added to UFILE

    :return: OMFIT UFILE data object
    """

    # Default to processing code: raw
    proc = 0

    if isinstance(date, datetime):
        shotdate = date.strftime('%d%b-%Y')
    else:
        shotdate = date

    # Create new UFILE and fill with data
    if os.path.exists('{}{:}.{:}'.format(pre, shot, ext)):
        os.remove('{}{:}.{:}'.format(pre, shot, ext))
    ufile = OMFITuFile('{}{}.{}'.format(pre, shot, ext))
    # The function
    ufile['F'] = {'name': 'ECH POWER', 'units': 'WATTS', 'data': z}
    ufile['X0'] = {'name': 'TIME', 'units': 'SEC', 'data': x}
    ufile['X1'] = {'name': 'SYSTEM NO', 'units': '', 'data': y}
    ufile['SCALARS'][0] = {'name': 'NGYRO', 'desc': '# OF GYROS', 'data': len(y)}
    ufile['SHOT'] = int(shot)
    ufile['DEVICE'] = device
    ufile['NDIM'] = len(ufile['F']['data'].shape)
    ufile['COMPRESSION'] = 0
    ufile['LSHOT'] = len(str(shot))
    ufile['PROCESSING_CODE'] = proc
    ufile['DATE'] = shotdate
    ufile['COMMENTS'] = ['Written by {:} using OMFIT'.format(os.environ['USER'])]
    if comment != '':
        ufile['COMMENTS'].append(comment)

    return ufile


# Function to create UFILES from MDS+ entries
def createUFILEmds(ext, pre='ORM', comment=''):
    """
    create ufile from INPUT subtree of TRANSP run stored in MDS+

    :param ext: UFILE extension to read from MDS+ and create

    :param pre: UFILE prefix i.e. 'OMF' for creation with OMFIT

    :param comment: comment to be added to UFILE

    :return: OMFIT UFILE data object
    """
    data = root['OUTPUTS']['TRANSP_OUTPUT']['INPUTS'][ext].data()
    units = root['OUTPUTS']['TRANSP_OUTPUT']['INPUTS'][ext].units()
    device = root['OUTPUTS']['TRANSP_OUTPUT']['DEVICE'].data()[0]
    shot = str(root['OUTPUTS']['TRANSP_OUTPUT']['SOURCE_SHOT'].data()[0])
    date = root['OUTPUTS']['TRANSP_OUTPUT']['DATE_RUN'].data()[0]
    name = root['OUTPUTS']['TRANSP_OUTPUT']['INPUTS'][ext]['LABEL'].data()[0]
    if not comment:
        try:
            root['OUTPUTS']['TRANSP_OUTPUT']['INPUTS'][ext]['COMMENT'].data()
        except Exception:
            pass

    # 1D U-file
    if len(data.shape) == 1:
        x = root['OUTPUTS']['TRANSP_OUTPUT']['INPUTS'][ext].dim_of(0)
        y = data
        return createHistoryUFILE(x=x, y=y, device=device, shot=shot, date=date, pre=pre, ext=ext, name=name, units=units, comment=comment)

    # 2D U-file
    elif len(data.shape) == 2:
        x = root['OUTPUTS']['TRANSP_OUTPUT']['INPUTS'][ext].dim_of(1)
        y = root['OUTPUTS']['TRANSP_OUTPUT']['INPUTS'][ext].dim_of(0)
        z = data
        return createProfileUFILE(
            x=x, y=y, z=z, device=device, shot=shot, date=date, pre=pre, ext=ext, name=name, units=units, comment=comment
        )
