# -*-Python-*-
# Created by mcclenaghanj at 07 Nov 2017  23:03
defaultVars(zaxis=None, gyrotron=scratch['gyrotron'], runid=root['SETTINGS']['EXPERIMENT']['runid'])


pol_range = root['SETTINGS']['PHYSICS']['pol_range']
tor_range = root['SETTINGS']['PHYSICS']['tor_range']

pol_length = len(pol_range)
tor_length = len(tor_range)


if zaxis is None:
    output_keys = 'currf', 'frac_absorbed', 'rho_max', 'rho_width'
else:
    output_keys = [zaxis]


outputs = {k: np.zeros([tor_length, pol_length]) for k in output_keys}
outputs_tb = {k: np.zeros([tor_length, pol_length]) for k in output_keys}

for i in range(tor_length):
    for j in range(pol_length):
        ij = i * pol_length + j
        for zaxis in output_keys:
            try:
                outputs[zaxis][i, j] = root['ANGLE_SCAN_FILES_' + gyrotron + '_' + runid][ij][zaxis]
            except Exception:
                outputs[zaxis][i, j] = np.nan
            try:
                outputs_tb[zaxis][i, j] = root['ANGLE_SCAN_FILES_' + gyrotron + '_' + runid][ij][zaxis + "_TB"]
            except Exception:
                outputs_tb[zaxis][i, j] = np.nan

for i_code, (code_output, title) in enumerate(zip([outputs, outputs_tb], ["TORAY", "TORBEAM"])):
    if i_code > 0:
        plt.figure()
    for i, zaxis in enumerate(output_keys):
        if zaxis == 'rho_width' and title == "TORBEAM":
            # Not supported yet
            continue
        if i > 0:
            plt.figure()

        CS = plt.contourf(pol_range, tor_range, code_output[zaxis], 20, cmap=plt.cm.jet)
        plt.colorbar()

        plt.xlabel('poloidal Angle')
        plt.ylabel('toroidal Angle')
        if zaxis == 'rho_max':
            plt.title(r'Peak deposition ($\rho$) ' + title)
        elif zaxis == 'currf':
            plt.title(r'Driven Ip (Amp/Watt) ' + title)
        elif zaxis == 'frac_absorbed':
            plt.title(r'fraction absorbed ' + title)
        elif zaxis == 'rho_width':
            plt.title(r'Deposition width ' + title)
