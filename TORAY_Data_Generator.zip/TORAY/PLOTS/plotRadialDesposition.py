# -*-Python-*-
# Created by mcclenaghanj at 28 Aug 2019  10:03

defaultVars(quantity='current', smooth=root['SETTINGS']['PHYSICS']['smoothing_window'], time_index=0)
from OMFITlib_functions import get_time_indices

fig = plt.figure(linewidth=8, figsize=(6, 4))
ax = fig.use_subplot(111)
for axis in ['top', 'bottom', 'left', 'right']:

    ax.spines[axis].set_linewidth(1.0)
ax.xaxis.set_tick_params(width=1)
ax.yaxis.set_tick_params(width=1)

plt.tick_params(axis='both', which='major', labelsize=14)


gyros = {
    root['INPUTS']['ods']['ec_launchers.beam'][item]['identifier']: item
    for item in root['INPUTS']['ods']['ec_launchers.code.parameters.beam']
    if root['INPUTS']['ods']['ec_launchers.code.parameters.beam'][item]['ON']
}

colors = color_cycle(len(gyros), cmap_name='rainbow')

total_y = None
xlabel(r'$\rho$', fontsize=16)
for k, gyro in enumerate(gyros):

    data = root['OUTPUTS'][gyro]['toray.nc']
    igyro = gyros[gyro]
    itime, itime_freq, itime_power = get_time_indices(igyro)
    power = root['INPUTS']['ods']['ec_launchers.beam'][igyro]['power_launched']['data'][time_index]

    color = colors[k]
    if 'power' in quantity:
        x = data['xmrho']['data']
        y = data['weecrh']['data'] * power
        if smooth:
            y = nu_conv(y, xi=x, window_size=smooth, window_function='hanning')
        plot(x, y, color=color, label=gyro)
        ylabel('Power absorption (W/cm$^2$)', fontsize=16)

    if 'current' in quantity:
        x = data['xmrho']['data']
        y = data['currf']['data'] * power
        if smooth:
            y = nu_conv(y, xi=x, window_size=smooth, window_function='hanning')
        plot(x, y, color=color, label=gyro)
        ylabel('Current drive (A/cm$^2$)', fontsize=16)

    if total_y is None:
        total_y = y
    else:
        total_y += y

plot(x, total_y, color='k', lw=1.5, label='total')

plt.legend()
fig.tight_layout()
