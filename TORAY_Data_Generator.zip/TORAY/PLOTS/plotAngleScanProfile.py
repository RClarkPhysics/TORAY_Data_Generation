# plot absorbtion, and current drive as the maximum value on each radial location

defaultVars(rho_averadge_width=0.03, gyrotron=scratch['gyrotron'], runid=root['SETTINGS']['EXPERIMENT']['runid'])


output_keys = 'currf', 'frac_absorbed', 'rho_max', 'rho_width'

pol_range = root['SETTINGS']['PHYSICS']['pol_range']
tor_range = root['SETTINGS']['PHYSICS']['tor_range']

pol_length = len(pol_range)
tor_length = len(tor_range)

outputs = {k: np.zeros([tor_length, pol_length]) for k in output_keys}

pol_range, tor_range = np.meshgrid(pol_range, tor_range)
for i in range(tor_length):
    for j in range(pol_length):
        ij = i * pol_length + j
        for zaxis in output_keys:
            try:
                outputs[zaxis][i, j] = root['ANGLE_SCAN_FILES_' + gyrotron + '_' + runid][ij][zaxis]
            except Exception:
                outputs[zaxis][i, j] = np.nan


outputs['pol'] = pol_range
outputs['tor'] = tor_range

outputs = {k: np.abs(v.flatten()) for k, v in outputs.items()}


isort = np.argsort(outputs['rho_max'])


width_list = []
currf_list = []
absorb_list = []
rho_currf = []
rho_absorb = []
rho_width = []
pol = []
tor = []
for rho in arange(0, 1, rho_averadge_width):
    ind = (rho < outputs['rho_max']) & (outputs['rho_max'] < rho + rho_averadge_width)  # & (absorb > 0.96)

    # ind &= (tor_range.flatten() > 180)

    if not any(ind):
        continue

    # find location of the highest current drive
    currf_loc = outputs['currf'][ind]
    ir = np.argmax(currf_loc)
    rho_currf.append(outputs['rho_max'][ind][ir])
    currf_list.append(currf_loc[ir])
    pol.append(outputs['pol'][ind][ir] - 90)
    tor.append(outputs['tor'][ind][ir] - 180)
    # find location with a narrowest deposition location with CD efficiency of atleast 90% of maximum
    width_loc = outputs['rho_width'][ind][outputs['currf'][ind] > currf_list[-1] * 0.9]
    if len(width_loc):
        ir = argmin(width_loc)
        width_list.append(width_loc[ir])
        rho_width.append(outputs['rho_max'][ind][outputs['currf'][ind] > currf_list[-1] * 0.9][ir])

    # absorbtion
    ir = np.argmax(outputs['frac_absorbed'][ind])
    rho_absorb.append(outputs['rho_max'][ind][ir])
    absorb_list.append(outputs['frac_absorbed'][ind][ir])


fig = gcf()
fig.set_size_inches(15, 5)
axes = fig.axes
if not axes:
    axes = [fig.add_subplot(141), fig.add_subplot(142), fig.add_subplot(143), fig.add_subplot(144)]


axes[0].plot(rho_absorb, absorb_list, lw=5, label=gyrotron)
axes[1].plot(rho_currf, currf_list, lw=5, label=gyrotron)
axes[2].plot(rho_width, width_list, lw=5, label=gyrotron)

axes[3].plot(rho_absorb, pol, lw=5, label='pol-90')
axes[3].plot(rho_absorb, tor, lw=5, label='tor-180')

axes[0].set_title('Absorbtion [-]')
axes[1].set_title('Current drive efficiency [A/W]')
axes[2].set_title('Width [-]')
axes[0].legend(loc='best')
axes[0].set_xlabel(r'$\rho$')
axes[1].set_xlabel(r'$\rho$')
axes[2].set_xlabel(r'$\rho$')
axes[3].set_xlabel(r'$\rho$')
axes[3].set_title('Angle [deg]')
axes[3].legend(loc='best')
axes[3].axhline(0, c='k')
