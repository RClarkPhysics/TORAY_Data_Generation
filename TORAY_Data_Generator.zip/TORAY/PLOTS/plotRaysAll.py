# -*-Python-*-
# Created by mcclenaghanj at 08 Nov 2017  10:54

gyros = {
    root['INPUTS']['ods']['ec_launchers.beam'][item]['identifier']: item
    for item in root['INPUTS']['ods']['ec_launchers.code.parameters']['beam']
    if root['INPUTS']['ods']['ec_launchers.code.parameters']['beam'][item]['ON']
}

colors = color_cycle(len(gyros), cmap_name='rainbow')

figure(num='Power absorption')
power_x = None
power_y = None

power_x_torbeam = None
power_y_torbeam = None

if len(gyros) == 1:
    colors = [None]

for k, gyro in enumerate(gyros):
    try:
        tmp = root['PLOTS']['plot_rays'].plot(
            gyrotron=gyro, igyrotron=gyros[gyro], color=colors[k], quantity=['power'], alpha=1.0 / len(gyros)
        )
        if power_x is None:
            power_x = tmp['power_x']
            power_y = tmp['power_y']
        else:
            power_y += tmp['power_y']
        if 'power_y_torbeam' in tmp:
            if power_x_torbeam is None:
                power_x_torbeam = tmp['power_x_torbeam']
                power_y_torbeam = tmp['power_y_torbeam']
            else:
                power_y_torbeam += tmp['power_y_torbeam']
    except Exception as _excp:

        printe('Error plotting %s: %s' % (gyro, repr(_excp)))
tmp['ax'].plot(power_x, power_y, 'k')
if power_x_torbeam is not None:
    tmp['ax'].plot(power_x_torbeam, power_y_torbeam, '--k')
tmp['ax'].legend()

figure(num='Current drive')
current_x = None
current_y = None
current_x_torbeam = None
current_y_torbeam = None
for k, gyro in enumerate(gyros):
    try:
        tmp = root['PLOTS']['plot_rays'].plot(
            gyrotron=gyro, igyrotron=gyros[gyro], color=colors[k], quantity=['current'], alpha=1.0 / len(gyros)
        )
        if current_x is None:
            current_x = tmp['current_x']
            current_y = tmp['current_y']
        else:
            current_y += tmp['current_y']
        if 'current_y_torbeam' in tmp:
            if current_x_torbeam is None:
                current_x_torbeam = tmp['current_x_torbeam']
                current_y_torbeam = tmp['current_y_torbeam']
            else:
                current_y_torbeam += tmp['current_y_torbeam']
    except Exception as _excp:
        printe('Error plotting %s: %s' % (gyro, repr(_excp)))
tmp['ax'].plot(current_x, current_y, 'k')
if current_x_torbeam is not None:
    tmp['ax'].plot(current_x_torbeam, current_y_torbeam, '--k')
tmp['ax'].legend()
