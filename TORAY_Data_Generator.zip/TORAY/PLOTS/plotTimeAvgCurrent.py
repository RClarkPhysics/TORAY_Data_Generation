# -*-Python-*-
# Created by mcclenaghanj at 07 Aug 2019  12:12
"""
This script collects the TORAY deposition profiles for a range of times to
plot as a single uncertainties band.

defaultVars parameters
----------------------
:param smooth: float. Smooths the profile in rho
:param ax: AXes. Plots in this axes (default None creates a new figure)
:param show_2sigma: bool. Shows a band for 1 and 2 sigma. Otherwise, uses standard uband (1 sigma).
:param show_efit: bool. Plots efit current density
:param scale_efit: float. Multiplier on the efit current (useful when ECCD is << J_EFIT for example)
:param xvar: str. Choose 'rho' or 'psi_n' as x axis for plot

"""
defaultVars(smooth=root['SETTINGS']['PHYSICS']['smoothing_window'], ax=None, show_2sigma=True, show_efit=True, scale_efit=1, xvar='rho')
from OMFITlib_functions import get_gyros, get_time_indices

gyros, gyroNames = get_gyros()

# make a new figure if not given an axis to plot in
if ax is None:
    fig, ax = subplots(figsize=(6, 4))
else:
    fig = ax.figure

# plot the full current according to the GRad-Shafranov equilibrium
gfile = root['INPUTS']['gEQDSK']
eshot = gfile['CASE'][3].replace('#', '')
etime = gfile['CASE'][4]
shot = root['SETTINGS']['EXPERIMENT']['shot']
if show_efit:
    if scale_efit != 1:
        prefix = rf'{scale_efit}$\times$ '
    else:
        prefix = ''
    ax.plot(
        gfile['RHOVN'], scale_efit * gfile['fluxSurfaces']['avg']['Jt'] * 1e-4, color='k', lw=1.8, label=f'{prefix}EFIT  {eshot} {etime}'
    )

rho = np.linspace(0, 1, 201)
# collect all the currents from each gyrotron at each time
currf_all = []
for time in root['SCAN_FILES']:
    currf = None
    for gyrotron in root['SCAN_FILES'][time]:
        if gyrotron != 'ods':
            igyro = gyros[gyroNames.index(gyrotron)]
            itime, itime_freq, itime_power = get_time_indices(igyro)

            power = root['SCAN_FILES'][time]['ods']['ec_launchers.beam'][igyro]['power_launched']['data'][itime_power]
            x = root['SCAN_FILES'][time][gyrotron]['toray.nc']['xmrho']['data']
            y = copy.deepcopy(root['SCAN_FILES'][time][gyrotron]['toray.nc']['currf']['data'] * power)

            if smooth:
                y = nu_conv(y, xi=x, window_size=smooth, window_function='boxcar')
            y = interp1e(x, y)(rho)
            if currf is None:
                currf = y
            else:
                currf += y

    currf_all.append(currf)

# reduce time dimension to a mean and uncertainty
currf_mean = np.mean(currf_all, axis=0)
currf_std = np.std(currf_all, axis=0)
if not len(root['SCAN_FILES']):
    printe('No scans are availible in root["SCAN_FILES"]')

tmin = int(min(root['SCAN_FILES'].keys()))
tmax = int(max(root['SCAN_FILES'].keys()))

if xvar == 'rho':
    xx = rho
    ax.set_xlabel(r'$\rho$', fontsize=16)
elif xvar == 'psi_n':
    aux = gfile['AuxQuantities']
    xx = interp1e(aux['RHO'], aux['PSI_NORM'])(rho)
    ax.set_xlabel(r'$\psi_N$', fontsize=16)
else:
    raise OMFITexception('xvar must be rho or psi_n')

if show_2sigma:
    (l,) = ax.plot(xx, currf_mean, lw=1.8, label=f'TORAY {tmin}-{tmax}ms')
    ax.fill_between(xx, currf_mean - currf_std, currf_mean + currf_std, color=l.get_color(), alpha=0.5, label=r'1 $\sigma$')
    ax.fill_between(xx, currf_mean + currf_std, currf_mean + 2 * currf_std, color=l.get_color(), alpha=0.25)
    ax.fill_between(xx, currf_mean - currf_std, currf_mean - 2 * currf_std, color=l.get_color(), alpha=0.25, label=r'2 $\sigma$')
    ax.legend()
else:
    currfu = unumpy.uarray(currf_mean, currf_std)
    uband(xx, currfu, ax=ax, label=f'ECCD {shot} {tmin}-{tmax}ms')
    ax.legend(loc=2, hide_markers=True, text_same_color=True)
ax.set_ylabel(r'J (A/$cm^2$)', fontsize=16)

fig.tight_layout()
