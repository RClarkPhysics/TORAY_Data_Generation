# -*-Python-*-
# Created by mcclenaghanj at 15 Jun 2017  01:10

from OMFITlib_functions import get_gyros

gyros, gyroNames = get_gyros()
ne_scan = {}
for ne_scale in sorted(list(root['NE_SCAN_FILES'].keys())):
    for gyro in gyroNames:
        if gyro in root['NE_SCAN_FILES'][ne_scale]:
            ne_scan.setdefault(gyro, []).append(root['NE_SCAN_FILES'][ne_scale][gyro]['toray.nc']['tpowde']['data'][-1])


ne0 = root['DATA']['ne'][0]
plt.axhline(y=0.9, color='black', linestyle='--')
for gyro in ne_scan:
    plt.plot(asarray(sorted(root['NE_SCAN_FILES'].keys())) * ne0, asarray(ne_scan[gyro]), label=gyro)
plt.xlabel('Central Density' + '$10^{19}$ $m^{-3}$')
plt.ylabel('frac power asorbed')
plt.ylim([0, 1.1])
plt.legend()
