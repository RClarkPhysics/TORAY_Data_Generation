# Python
# originally by Orso
# modified by Zhixuan 1/7/2015

defaultVars(
    fig=None,
    gyrotron='Leia',
    igyrotron=0,
    color=None,
    quantity=['power', 'current'][:1],
    alpha=0.5,
    smooth=root['SETTINGS']['PHYSICS']['smoothing_window'],
    downsamp=1,
)

from OMFITlib_functions import get_time_indices

itime, itime_freq, itime_power = get_time_indices(igyrotron)

location = root['OUTPUTS']
if gyrotron:
    location = location[gyrotron]

data = location['toray.nc']

if compare_version(root['INPUTS']['ods'].imas_version, "3.37.0") >= 0:
    beam = "beam"
else:
    beam = "launcher"

power = 1.0
power_units = '\n' + data['weecrh']['units']
current_units = data['currf']['units']
if gyrotron:
    power = float(root['INPUTS']['ods']['ec_launchers'][beam][igyrotron]['power_launched']['data'][itime_power])
    power_units = 'MW/m$^3$'
    current_units = 'MA/m$^2$'

gfile = root['INPUTS']['gEQDSK']
phi_exp = root['INPUTS']['ods'][f'ec_launchers.{beam}[{igyrotron}].launching_position.phi'][itime]

# get/calculate physical quantites for rays
wr = data['wr']['data'][::downsamp, ::downsamp]
mask = ones(wr.shape)
mask[where(wr == 0)] = nan
mask = mask.T

wphi = data['wphi']['data'][::downsamp, ::downsamp].T * mask
wr = wr.T * mask / 100.0
wxt = wr * cos(-wphi)
wyt = wr * sin(-wphi)
wx = wxt * cos(phi_exp) - wyt * sin(phi_exp)
wy = wyt * cos(phi_exp) + wxt * sin(phi_exp)

wz = data['wz']['data'][::downsamp, ::downsamp].T * mask / 100.0

x0t = data['x0']['data'][0] / 100.0
y0t = data['y0']['data'][0] / 100.0

x0 = x0t * cos(phi_exp) - y0t * sin(phi_exp)
y0 = x0t * sin(phi_exp) + y0t * cos(phi_exp)

z0 = data['z0']['data'][0] / 100.0
x1t = wr[0, 0] * cos(-wphi[0, 0])
y1t = wr[0, 0] * sin(-wphi[0, 0])
x1 = x1t * cos(phi_exp) - y1t * sin(phi_exp)
y1 = x1t * sin(phi_exp) + y1t * cos(phi_exp)
z1 = data['wz']['data'].T[0, 0] / 100.0

s = data['delpwr']['data'][::downsamp, ::downsamp].T
s = s / s[0]
# plt.plot( -wy, s )
# OMFITx.End()
# toroidal cross-section
subplot(2, 2, 1, aspect='equal')
if 'torbeam' in root['OUTPUTS'][gyrotron]:
    torbeam = True
    print(f"Found TORBEAM results for {gyrotron}")
else:
    torbeam = False
if color:
    plot(wx * mask, wy * mask, color=color, label=gyrotron, alpha=alpha)
    if torbeam:
        plot(
            root['OUTPUTS'][gyrotron]['torbeam']["x"].T,
            root['OUTPUTS'][gyrotron]['torbeam']["y"].T,
            color=color,
            label=gyrotron,
            alpha=alpha,
            linestyle="dashed",
        )
else:
    plotc(wx, wy, s * mask, alpha=alpha, cmap='Reds')
    if torbeam:
        plot(
            root['OUTPUTS'][gyrotron]['torbeam']["x"].T,
            root['OUTPUTS'][gyrotron]['torbeam']["y"].T,
            label=gyrotron,
            alpha=alpha,
            linestyle="dashed",
        )
plot([x0, x1], [y0, y1], 'k')
xlabel('X[m]')
ylabel('Y[m]')
gca().set_frame_on(False)

if isinstance(gfile, OMFITgeqdsk):
    # plot the boundary
    Rout = max(gfile['RBBBS'])
    Rin = min(gfile['RBBBS'])
    t_angle = arange(0, 2 * pi, 0.02 * pi)
    t_angle = append(t_angle, 2 * pi)
    Xout = Rout * cos(t_angle)
    Yout = Rout * sin(t_angle)
    Xin = Rin * cos(t_angle)
    Yin = Rin * sin(t_angle)
    plot(Xin, Yin, 'k')
    plot(Xout, Yout, 'k')

    # calculate the resonance field
    B_res = data['freqcy']['data'] / 2.802e10

    # approximate resonant surface
    R_res = abs(gfile['RCENTR'] * gfile['BCENTR'] / B_res)
    X_res = R_res * cos(t_angle)
    Y_res = R_res * sin(t_angle)
    plot(X_res, Y_res, 'r--')

title('Toroidal view')

# power absorption & current drive
ax = subplot(2, 2, 3)
xlabel('$\\rho$')

if 'power' in quantity:
    power_x = data['xmrho']['data']
    power_y = data['weecrh']['data'] * power  # W/cm^3 -> MW/m^3
    if smooth:
        power_y = nu_conv(power_y, xi=power_x, window_size=smooth, window_function='hanning')
    ax.plot(power_x, power_y, color=color, label=gyrotron)
    if torbeam:
        power_x_torbeam = root['OUTPUTS'][gyrotron]['torbeam']["rho"]
        power_y_torbeam = root['OUTPUTS'][gyrotron]['torbeam']["power density"] * power  # TORBEAM ran with 1 W and result is in MW
        plot(
            power_x_torbeam,
            power_y_torbeam,
            color=color,
            label=gyrotron + " TORBEAM",
            linestyle="dashed",
        )
    ax.set_ylabel('Power absorption ' + power_units)


if 'current' in quantity:
    current_x = data['xmrho']['data']
    current_y = data['currf']['data'] * power / 100.0  # A/cm^2 -> MA/m^2
    if smooth:
        current_y = nu_conv(current_y, xi=current_x, window_size=smooth, window_function='hanning')
    ax.plot(current_x, current_y, color=color, label=gyrotron)
    if torbeam:
        current_x_torbeam = root['OUTPUTS'][gyrotron]['torbeam']["rho"]
        # TORBEAM ran with 1 W, its result is in MA/m^2 and we are plotting kA/m^2
        current_y_torbeam = -root['OUTPUTS'][gyrotron]['torbeam']["current density"] * power
        plot(
            current_x_torbeam,
            current_y_torbeam,
            color=color,
            label=gyrotron + " TORBEAM",
            linestyle="dashed",
        )
    ax.set_ylabel('Current drive ' + current_units)

# poloidal cross-section
subplot(1, 2, 2)  # ,aspect='equal')
if isinstance(gfile, OMFITgeqdsk):
    Zmax = max(gfile['ZLIM'])
    Zmin = min(gfile['ZLIM'])
    gfile.plot(only2D=True, color='grey')

    # accurate resonant surface
    R, Z = meshgrid(gfile['AuxQuantities']['R'], gfile['AuxQuantities']['Z'])
    B = sqrt(gfile['AuxQuantities']['Bt'] ** 2 + gfile['AuxQuantities']['Br'] ** 2 + gfile['AuxQuantities']['Bz'] ** 2)
    contour(R, Z, B, [B_res], colors='r')

    # approximate resonant surface, as the one shown in the toroidal view
    plot([R_res, R_res], [Zmin, Zmax], 'r--')
    gca().set_frame_on(False)

if color:
    plot(wr * mask, wz * mask, lw=4, color=color, label=gyrotron, alpha=alpha)
    if torbeam:
        plot(
            root['OUTPUTS'][gyrotron]['torbeam']["R"].T,
            root['OUTPUTS'][gyrotron]['torbeam']["z"].T,
            color=color,
            label=gyrotron,
            alpha=alpha,
            linestyle="dashed",
        )
else:
    plotc(wr, wz, s, alpha=alpha, cmap='Reds')
    if torbeam:
        plot(
            root['OUTPUTS'][gyrotron]['torbeam']["R"].T,
            root['OUTPUTS'][gyrotron]['torbeam']["z"].T,
            label=gyrotron,
            alpha=alpha,
            linestyle="dashed",
        )

plot([x0t, x1t], [z0, z1], 'k')
xlabel('R[m]')
ylabel('Z[m]')

title('Poloidal view')
