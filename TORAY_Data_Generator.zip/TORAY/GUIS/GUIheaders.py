# -*-Python-*-
# Created by meneghini at 12 Jul 2017  00:13

defaultVars(updateProfilesButton=True)

runTypeOptions = ['Standard toray run', 'Scan time', 'Time dependent critical ne', 'ne scan', 'Angle scan']
OMFITx.ComboBox("root['SETTINGS']['SETUP']['runType']", runTypeOptions, 'Run type', updateGUI=True)

if root['SETTINGS']['PHYSICS']['inputDATA'] in ['OMFITprofiles', 'kineticEFITtime', 'ZIPFITs']:
    OMFITx.ShotTimeDevice(showTime=False)
else:
    OMFITx.ShotTimeDevice()

OMFITx.ComboBox(
    "root['SETTINGS']['PHYSICS']['inputDATA']",
    ['ZIPFITs', 'OMFITprofiles', 'QUICKFIT', 'kineticEFITtime', 'PRO_create', 'ODS'],
    'Input data',
    updateGUI=True,
)


def set_kineticEFIT_OMFITprofiles_dependency(location):
    root['SETTINGS']['DEPENDENCIES']['OMFITprofiles'] = f"{root['SETTINGS']['DEPENDENCIES']['kineticEFITtime']}['OMFITprofiles']"


if root['SETTINGS']['PHYSICS']['inputDATA'] in ['OMFITprofiles', 'QUICKFIT']:
    OMFITx.ModulePicker(
        "root['SETTINGS']['DEPENDENCIES']['profiles_module']", ['OMFITprofiles', 'QUICKFIT'], 'profiles module', updateGUI=True
    )
    try:
        time_shared = np.int_(profiles_module['OUTPUTS']['FIT']['time'].values).tolist()
    except Exception:
        time_shared = []
    OMFITx.ComboBox("root['SETTINGS']['EXPERIMENT']['time']", time_shared, 'Time[ms]')


elif root['SETTINGS']['PHYSICS']['inputDATA'] == 'kineticEFITtime':
    OMFITx.ModulePicker(
        "root['SETTINGS']['DEPENDENCIES']['kineticEFITtime']",
        'kineticEFITtime',
        'kineticEFITtime module',
        updateGUI=True,
        postcommand=set_kineticEFIT_OMFITprofiles_dependency,
    )
    try:
        time_shared = kineticEFITtime['SETTINGS']['EXPERIMENT']['times'].tolist()
    except Exception:
        time_shared = []
    OMFITx.ComboBox("root['SETTINGS']['EXPERIMENT']['time']", time_shared, 'Time[ms]')

elif root['SETTINGS']['PHYSICS']['inputDATA'] == 'PRO_create':
    OMFITx.ModulePicker("root['SETTINGS']['DEPENDENCIES']['PRO_create']", 'PRO_create', 'PRO_create module', updateGUI=True)

elif root['SETTINGS']['PHYSICS']['inputDATA'] == 'ODS':
    OMFITx.ObjectPicker("root['INPUTS']['ods']", 'ODS', None)

else:
    shot = root['SETTINGS']['EXPERIMENT']['shot']

    if is_device(root['SETTINGS']['EXPERIMENT']['device'], "DIII-D"):
        # Makes list of times shared by mds+ gfiles and zipfits
        efit = root['SETTINGS']['PHYSICS']['EFIT_type']
        # save availible ZIPFIT & EFIT time to scratch
        if not f'zipfit_{efit}_{shot}' in scratch:
            MDS = OMFITmds('DIII-D', efit, shot)
            time_gfile = tolist(MDS['RESULTS']['GEQDSK']['GTIME'].data())
            time_zip_ne = OMFITmdsValue(
                treename='ZIPFIT01',
                TDI='\\ZIPFIT01::TOP.PROFILES.EDENSFIT',
                shot=shot,
                quiet=False,
                server='DIII-D',
            ).dim_of(1)

            time_zip_te = OMFITmdsValue(
                treename='ZIPFIT01',
                TDI='\\ZIPFIT01::TOP.PROFILES.ETEMPFIT',
                shot=shot,
                quiet=False,
                server='DIII-D',
            ).dim_of(1)

            time_shared = set(time_zip_te).intersection(time_zip_ne)
            time_shared = set(time_gfile).intersection(time_shared)
            time_shared = np.sort(tolist(time_shared))
            time_shared = [int(i) for i in time_shared]
            scratch[f'zipfit_{efit}_{shot}'] = time_shared
        else:
            time_shared = scratch[f'zipfit_{efit}_{shot}']

        snap_list, help = available_EFITs(scratch, root['SETTINGS']['EXPERIMENT']['device'], shot)
        OMFITx.ComboBox("root['SETTINGS']['PHYSICS']['EFIT_type']", snap_list, 'EFIT type', state='normal')

        OMFITx.ComboBox("root['SETTINGS']['EXPERIMENT']['time']", time_shared, 'Time[ms]')
    else:
        printe(f"ZIPFITs not available for {root['SETTINGS']['EXPERIMENT']['device']}")

if updateProfilesButton:
    OMFITx.Button('Setup profiles and equilibrium', "root['SCRIPTS']['generate_profiles']")

OMFITx.Entry("root['SETTINGS']['EXPERIMENT']['gyro_shot']", 'Gyrotron shot', default=None)

OMFITx.Entry("root['SETTINGS']['EXPERIMENT']['gyro_time']", 'Gyrotron Time [ms]', default=None)

OMFITx.Button('Setup ECH powers and aimings from MDS+', "root['SCRIPTS']['fetchGyrotronsData']")

if 'ods' not in root['INPUTS'] or 'ec_launchers' not in root['INPUTS']['ods']:
    OMFITx.End()

runType = root['SETTINGS']['SETUP']['runType']
if runType == 'ne scan':
    OMFITx.CompoundGUI(root['GUIS']['torayNeScanGUI'], '')
elif runType == 'Time dependent critical ne':
    OMFITx.CompoundGUI(root['GUIS']['torayCriticalNeGUI'], '')

elif runType == 'Scan time':
    OMFITx.CompoundGUI(root['GUIS']['torayTimeScanGUI'], '')
elif runType == 'Angle scan':
    OMFITx.CompoundGUI(root['GUIS']['torayAngleScanGUI'], '')
else:
    OMFITx.CompoundGUI(root['GUIS']['torayGUI'], '')
