# -*-Python-*-
# Created by mcclenaghanj at 28 Feb 2020  11:13

beam = "beam"
cparam_beams = root['INPUTS']['ods']['ec_launchers.code.parameters'][beam]
beams = root['INPUTS']['ods']['ec_launchers'][beam]
with OMFITx.same_row():
    for ibeam in cparam_beams:
        OMFITx.CheckBox(
            f"root['INPUTS']['ods']['ec_launchers.code.parameters']['{beam}'][{ibeam}]['ON']",
            beams[ibeam]['identifier'],
            useInt=True,
            updateGUI=True,
        )

# OMFITx.CheckBox(
#     "root['SETTINGS']['SETUP']['run_gyros_in_parallel']",
#     "Run Gyros in parallel",
#     default=True,
#     help="If the parallel jobs are stuck, the code may have hung.\n"
#     + "Run not in parallel to get verbose error messages and hunt down the issue.",
# )
