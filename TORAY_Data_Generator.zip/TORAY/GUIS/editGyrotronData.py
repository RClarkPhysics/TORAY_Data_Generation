# -*-Python-*-
# Created by mcclenaghanj at 08 Nov 2017  10:51
from OMFITlib_functions import get_gyros, get_time_indices

gyros, gyroNames = get_gyros()
OMFITx.ComboBox("scratch['gyrotron']", gyroNames, 'Edit gyrotron', updateGUI=True, default=None)

beam = "beam"
ech_ods = root['INPUTS']['ods']['ec_launchers']
ech_ods_ = "root['INPUTS']['ods']['ec_launchers']"


def update_angles(location, igyro):
    ech_ods[f'{beam}[{igyro}].steering_angle_tor'][itime] = np.radians(scratch['angle_tor'] - 180.0)
    ech_ods[f'{beam}[{igyro}].steering_angle_pol'][itime] = np.radians(scratch['angle_pol'] - 90.0)


if scratch['gyrotron'] is not None:
    gyro = scratch['gyrotron']
    if gyro not in gyroNames:
        scratch['gyrotron'] = None
    else:
        igyro = gyros[gyroNames.index(gyro)]

        itime, itime_freq, itime_power = get_time_indices(igyro)
        modeOptions = {'X-mode': -1, 'O-mode:': 1}
        OMFITx.ComboBox(f"root['INPUTS']['ods']['ec_launchers.{beam}[{igyro}].mode']", modeOptions, 'Xfraction', updateGUI=True)
        if root['INPUTS']['ods'][f'ec_launchers.{beam}[{igyro}].mode'] == 1:
            OMFITx.CheckBox(
                f"root['INPUTS']['toray.in']['EDATA']['idamp']",
                'Use IDAMP = 2',
                mapFalseTrue=[8, 2],
                default=8,
                help='TORAY is using IDAMP=8 by default, it predicts too high absorbtion of O-mode for radial injection. \n In such case, IDAMP=2 works better.  ',
            )
        else:
            if 'toray.in' in root['INPUTS']:
                root['INPUTS']['toray.in']['EDATA'].pop('idamp', None)

        OMFITx.Entry(ech_ods_ + f"['{beam}[{igyro}].launching_position.r'][{itime}]", 'launch R' + ' [m]')
        OMFITx.Entry(ech_ods_ + f"['{beam}[{igyro}].launching_position.z'][{itime}]", 'launch Z' + ' [m]')
        OMFITx.Entry(ech_ods_ + f"['{beam}[{igyro}].launching_position.phi'][{itime}]", 'launch_phi' + ' [degrees]', norm=pi / 180.0)
        scratch['angle_tor'] = np.degrees(ech_ods[beam][igyro]['steering_angle_tor'][itime]) + 180.0
        scratch['angle_pol'] = np.degrees(ech_ods[beam][igyro]['steering_angle_pol'][itime]) + 90.0
        OMFITx.Entry("scratch['angle_tor']", 'torAngle' + ' [degrees]', postcommand=lambda location: update_angles(location, igyro))
        OMFITx.Entry("scratch['angle_pol']", 'polAngle' + ' [degrees]', postcommand=lambda location: update_angles(location, igyro))

        OMFITx.Entry(ech_ods_ + f"['{beam}[{igyro}].frequency.data'][{itime_freq}]", 'frequency' + ' [GHz]', norm=1e9)
        OMFITx.Entry(ech_ods_ + f"['{beam}[{igyro}].power_launched.data'][{itime}]", 'power' + ' [MW]', norm=1e6)
        OMFITx.Entry(ech_ods_ + f"['code.parameters']['{beam}'][{igyro}]['mharm']", 'mharm')
