# -*-Python-*-
# Created by mcclenaghanj at 08 Nov 2017  10:38

OMFITx.TitleGUI('TORAYGUI')

# ============================
OMFITx.Tab('Run')
OMFITx.CompoundGUI(root['GUIS']['gyrotron_checkbox'], '')
OMFITx.Button('Run TORAY', "root['SCRIPTS']['run_toray_all_gyrotrons']")

OMFITx.Separator()

if len(root['OUTPUTS']):
    OMFITx.Entry("root['SETTINGS']['PHYSICS']['smoothing_window']", 'Smoothing window')
    OMFITx.Button('Plot summary', "root['PLOTS']['plotRaysAll']")
    OMFITx.Button('Plot current drive', lambda: root['PLOTS']['plotRadialDeposition'].run(quantity='current'))
    OMFITx.Button('Plot power deposition', lambda: root['PLOTS']['plotRadialDeposition'].run(quantity='power'))

# ============================
OMFITx.Tab('Edit gyrotron')

OMFITx.CompoundGUI(root['GUIS']['editGyrotronData'], '')
