# -*-Python-*-
# Created by mcclenaghanj at 07 Nov 2017  14:17


OMFITx.TitleGUI('TORAY SCAN GUI')

# ============================
OMFITx.Tab('Run')

OMFITx.Separator('Active Gyrotrons')
OMFITx.CompoundGUI(root['GUIS']['gyrotron_checkbox'], '')
OMFITx.Separator('Scan parameters')
OMFITx.Entry("root['SETTINGS']['PHYSICS']['ne_scan']", 'Scan scale n_e')
OMFITx.CheckBox("root['SETTINGS']['PHYSICS']['append_scan_results']", 'Append scan results', default=True)
OMFITx.Button('Run density scan', root['SCRIPTS']['scan_ne'])

if len(root['NE_SCAN_FILES']) > 0:
    OMFITx.Separator('Plotting')
    OMFITx.Button('Plot fraction of power absorbed', root['PLOTS']['plotNeScan'].plot)
